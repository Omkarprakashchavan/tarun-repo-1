import copy
import json
import os
import sys
import yaml
from typing import List

sys.path.append(f'{os.path.dirname(__file__)}/..')
from utils.github_apis import GitHubAPIs
import utils.myutils as mu


logger = None
gh_obj = None
topdir = os.path.dirname(__file__)
logdir = f'{topdir}/logdir'

# data structure for default branch protection policy is contructed in main functuion 
# based on the values from github-policies.yaml
def main(repo_exclude_list, module_description, module_name, default_policy, repo_policy_override_list):
    return
    if not default_policy:
        print('ERROR: The "policy_defaults" key is missing in the YAML config file!')
        sys.exit(1)
 
    
    token = os.environ.get("GIT_HUB_TOKEN")
    mu.mkdir_p(logdir)
    global logger
    global gh_obj
    ### Change values accordingly in get_logger()
    logger = mu.get_logger('branch-protection', f'{logdir}/branch-protection.log', 
                           level='debug', output_to_console=True)
    gh_obj = GitHubAPIs(org_name='glcp', token=token, logger=logger)

    final_repo_list=[]
    default_branch_protection_policy={
       "required_status_checks": {
          "strict": True,
          "contexts": []
       },
       "enforce_admins": False,
       "required_pull_request_reviews": {
          "require_code_owner_reviews": 
             default_policy['require_code_owner_reviews'],
          "require_last_push_approval": 
             default_policy['require_last_push_approval'],
          "required_approving_review_count": 
             default_policy['required_approving_review_count']
       },
    # restrictions key will be set later on in this main function  
    #    "restrictions": None 
    }

    logger.debug(f'Final list of Repos in the glcp org')
    counter : int = 1
    # repos : List[str] = []
    repos : List[str] = gh_obj.get_repo_names_in_org()

    for i in repos:
        if i not in repo_exclude_list:
            # default_branch: str = gh_obj.get_default_branch(i)
            final_repo_list.append(i)
            # print(f'{counter}: {i} {default_branch}')
            print(f'{counter}: {i}')
            counter+=1

    logger.debug(f'Repos that have override policy: {repo_policy_override_list}')
    # final_repo_list=['sridhar-hdu','sridhar-py','sridhar','aws-hpe_onepass_2_dev-config'] # TODO remove
    repo_bpp_info={}
    fbpp_info={}
    repos_to_be_updated=[]
    counter : int = 1
    for i in final_repo_list:
        policy_override={}
        # Check if the override policy exsists for the current repo being processed.
        for d in repo_policy_override_list:
            if i == d['repo_name']:
                policy_override=d['overrides']
                break
        # if the policy override exsists then we will update default protection policy with the 
        # overriding values for the current repo else we will send default protection policy to the current repo
        if policy_override:
            repos_to_be_updated.append(i)
            bpp = copy.deepcopy(default_branch_protection_policy)
            if 'require_code_owner_reviews' in policy_override:
                logger.debug(f'''Override Policy "require_code_owner_reviews" for the repo {i} is: {policy_override['require_code_owner_reviews']}''')
                bpp['required_pull_request_reviews']['require_code_owner_reviews']=\
                policy_override['require_code_owner_reviews']
            if 'require_last_push_approval' in policy_override:
                logger.debug(f'''Override Policy "require_last_push_approval" for the repo {i} is: {policy_override['require_last_push_approval']}''')
                bpp['required_pull_request_reviews']['require_last_push_approval']=\
                policy_override['require_last_push_approval']
            if 'required_approving_review_count' in policy_override:
                logger.debug(f'''Override Policy "required_approving_review_count" for the repo {i} is: {policy_override['required_approving_review_count']}''')
                bpp['required_pull_request_reviews']['required_approving_review_count']=\
                policy_override['required_approving_review_count']
        else:
        # If the repo do not have any policy override then it uses the default policy       
            bpp = default_branch_protection_policy

        repo_bpp_info[i]=bpp
        default_branch: str = gh_obj.get_default_branch(i)
        print(f'{counter}: Repo_Name={i} default_branch={default_branch}')

    
        final_branch_protection_policy={} # This will be set by track_repos_to_be_updated()
        track_repos_to_be_updated(i,counter,default_policy,default_branch_protection_policy,repos_to_be_updated,final_branch_protection_policy)

        # Original branch protection policy data structure for the repo looks like:   "block_creations": {"enabled": true}
        # This causes the set_branch_protection() to fail because the data structcure is incorrect.
        # This for loop will fix the data structure to look like: "block_creations": true 
        #
        for k in ['allow_fork_syncing','lock_branch','required_conversation_resolution',
                'block_creations','allow_deletions','allow_force_pushes','required_linear_history',
                'required_signatures']:
            if k in final_branch_protection_policy:
                final_branch_protection_policy[k]=final_branch_protection_policy[k]['enabled']
        fbpp_info[i]=final_branch_protection_policy
        counter+=1



    counter : int = 1
    # removing the duplicate reponames from the repos_to_be_updated list
    repos_to_be_updated=list(dict.fromkeys(repos_to_be_updated))
    # We are updating the branch protection policy for the repo's that do not match with default/override policy.
    for i in repos_to_be_updated:
        fbpp=copy.deepcopy(fbpp_info[i])
        logger.debug(f'current repo to be updated {i}')
        default_branch: str = gh_obj.get_default_branch(i)
        logger.debug(f'{counter}: Repo_Name={i} default_branch={default_branch}')
        branch_protection_policy=repo_bpp_info[i]
        logger.debug(f'Desired branch protection policy for repo {i} is {json.dumps(branch_protection_policy,indent=2)}')   
        logger.debug(f'This is original branch protection policy from repo {i} is {json.dumps(fbpp,indent=2)}')
        # This for-loop will contruct the necessary data structure with all the required keys/policies, 
        # including the enforced/desired policies.
        for k in branch_protection_policy:
            # if 'required_status_checks' exsists in the github then dont override with the default value.
            if k=='required_status_checks' and k in fbpp:
                continue
            fbpp[k]=branch_protection_policy[k]
            # If restrictions policy is missing from the original branch protection policy, then we need to 
            # set the value to None in the final branch protection policy (the fbpp dictionary).
            # Otherwise github api will complain key is missing.
            if 'restrictions' not in fbpp:
                fbpp['restrictions']=None
        # github doesnot like 'checks' key to be present when setting up the branchig protection
        fbpp['required_status_checks'].pop('checks', None)
        logger.debug(f'Final Branch protection Policy that will be applied to repo {i} with all required keys is {json.dumps(fbpp,indent=2)}')
        gh_obj.set_branch_protection(fbpp,default_branch,i)
        counter+=1

    mu.create_log_file(module_name=module_name, module_description=module_description, 
                count_final_repo_list=len(final_repo_list), count_repo_exclude_list=len(repo_exclude_list),
                 repos_to_be_updated=repos_to_be_updated)



#This function will compare the current settings of repo in the github against the default policy
#If any policy doesn't match the default then the default policy , this function will record the reponame
# in the repos_to_be_updated list.
def track_repos_to_be_updated(repo_name,counter,default_policy,default_branch_protection_policy,repos_to_be_updated=[],branch_protection_policy={}):
    default_branch: str = gh_obj.get_default_branch(repo_name)
    print(f'{counter}: repo_Name={repo_name} default_branch={default_branch}')
        # This if block will keep track of all the repo's need to be updated with the branch protection policy.
    try:
        cbpe=gh_obj.check_branch_protection_enabled(default_branch,repo_name)
    except Exception:
        logger.warning(f'repo "{repo_name}" appears to be empty...skipping')
        return

    if cbpe:
        obp=gh_obj.get_branch_protection(default_branch,repo_name)
        branch_protection_policy.update(obp)
        # logger.debug(f'Original branch protection policy before modification for repo {repo_name} is {json.dumps(obp,indent=2)}')
        try:
            logger.debug(f'''Current Policy "require_code_owner_reviews" for repo {repo_name} is: {obp.get('required_pull_request_reviews',{}).get('require_code_owner_reviews',None)}''')
            logger.debug(f'''Current Policy "require_last_push_approval" for repo {repo_name} is : {obp.get('required_pull_request_reviews',{}).get('require_last_push_approval',None)}''')
            logger.debug(f'''Current Policy "required_approving_review_count" for repo {repo_name} is: {obp.get('required_pull_request_reviews',{}).get('required_approving_review_count',0)}''')
            logger.debug(f'''Current Policy "enforce_admins" for repo {repo_name} is: {obp.get('enforce_admins',{}).get('enabled',None)}''')
            if obp.get('required_pull_request_reviews',{}).get('require_code_owner_reviews',None)!= default_policy['require_code_owner_reviews']  or \
                obp.get('required_pull_request_reviews',{}).get('require_last_push_approval',None)!= default_policy['require_last_push_approval'] or \
                obp.get('required_pull_request_reviews',{}).get('required_approving_review_count',0)!=default_policy['required_approving_review_count'] or \
                obp.get('enforce_admins',{}).get('enabled',None)!=default_branch_protection_policy['enforce_admins']:
                
                # obp.get('enforce_admins',{}).get('enabled',None)!= default_policy['enforce_admins']:
                    repos_to_be_updated.append(repo_name)
                    print(f'Here 1')
        except KeyError:
                repos_to_be_updated.append(repo_name)
                print(f'Here 2')
    else:
        branch_protection_policy.update({})
        repos_to_be_updated.append(repo_name)
        print(f'Here 3')





