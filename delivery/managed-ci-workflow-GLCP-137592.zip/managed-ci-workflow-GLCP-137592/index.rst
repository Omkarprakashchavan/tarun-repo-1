GLCP
=====================================

`View on github`_

.. _View on github: https://github.com/glcp/managed-ci-workflow/


.. toctree::
   :caption: GLCP platform developers
   :glob:

   docs/glcp-developers/Managed-ci/index.rst
   docs/glcp-developers/change-log/README.md

