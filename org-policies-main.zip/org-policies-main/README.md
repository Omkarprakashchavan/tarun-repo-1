# Automation framework to scan GLCP repos 


<!-- [Github](https://www.github.com)

|Name|Email|Address|
|----|-----|-------|
|John|john@example.com|Address| -->

 This repo contains Automation framework to scan all GLCP repos and execute the business logic by the respective python module, for example **branch_protection** module enables branch protection policy to all the glcp repo's and **pull_request_template** module enforces the 
PULL REQUEST TEMPLATE to all the glcp repo's under .github folder.

The GitHub action "mainline-branch-protection.yaml" used to conduct this automation each day at midnight calls the Python script "main.py" and passes it the "GIT HUB TOKEN" that the GitHub APP generated. The Python script runs each of the modules mentioned in **github-policies.yaml** in the order specified in the yaml file.

This repo contains the following files and folders.

1. **github-policies.yaml:**
2. **productModules**
3. **utils**
4. **main.py**
5. **branch-protection-reports**

# github-policies.yaml

The most crucial file that repository owners should concentrate on is **github-policies.yaml** and create a pull request to this repo 
if their repository has to be exempted from the scan, meaning that repo won't be deployed with the pull request template or applied with branch protection policy etc.

1. If a repository owner wants to exclude their repository from all security enforcement, they should add their repository to the **default** module **repo_scan_exclusions** list. This will prevent their repository from being scanned for branch protection, pull request template enforcement, and any other security policy enforcement. The repository owner must make this modification and send a PR to the **Giotto** team.
2. Assume that a repository owner does not want his repository to be included solely for branch protection policy. In this case, the repository owner should add his repository to the **branch_protection** module **repo_scan_exclusions** list so that it will not be included in the branch protection policy.The repository owner must make this modification and send a PR to the **Giotto** team.

This file **github-policies.yaml** contains the order of the modules imported and executed by the **main.py** python script. 

``` 
# This file contains the order of the modules imported and executed by the main python script
# Repos that are mentioned under "repo_scan_exclusions" will be passed in to each module.
###=====================================================================================###

modules:   
  - name: default
    description: Repositories excluded from all the scan's and policy enforcement.
    repo_scan_exclusions:
        - repo-name-10
        - repo-name-14
        - repo-name-3  

###=====================================================================================###
  - name: branch_protection
    description: Repo branch protection policy
    policy_defaults:
        require_code_owner_reviews: true
        require_last_push_approval: true
        required_approving_review_count: 2
    repo_scan_exclusions:
        - repo-name-9
        - repo-name-2
        - repo-name-3
        - repo-name-4      
    repo_policy_overides:
        - repo_name: hop-ingest-aluong-testit
          overrides:
              required_approving_review_count: 1
        - repo_name: aluong-harmony-jupyter-notebook-metadata
          overrides:
              require_code_owner_reviews: true
              require_last_push_approval: false
              required_approving_review_count: 3
        - repo_name: hop-ingest-metadata-penne-aluong-testit
          overrides:
              require_code_owner_reviews: false
              require_last_push_approval: false

###=======================================================================================###
  - name: pull_request_template
    description: Pull Request Template enforcement
    repo_scan_exclusions:
        - repo-name-5
        - repo-name-6
        - repo-name-11
```

# productModules Folder:

   This folder **productModules** contains the modules that are specified in the **github-policies.yaml** file. For instance, the **branch_protection** module is defined in the **github-policies.yaml**  file, so a python script called **branch_protection.py** with the corresponding business logic must be present under the productModules folder.Let's say we want to add a new security policy module later. All we have to do is add the module to the **github-policies.yaml** file and create a python script with the appropriate business logic under the productModules folder.The name of the Python script file must match the name of the module listed in the **github-policies.yaml** file.
   
The following security policy modules are now available in productModules, more information is provided below.

**branch_protection.py:**

1. branch_protection.py script which is part of productModules folder has the ability to scan all the GLCP Org Repo's and exclude the repo's mentioned under **default**  and **branch_protection** modules from **github-policies.yaml** **repo_scan_exclusions** list then apply the branch protection policies to the final list of repo's.This script will take care of override the default policy for the repo's mentioned under **repo_policy_overides** list.
 
2. **branch_protection**  has the following things:
      1. **policy_default:** has the default policies that all the repo's will be applied with
      2. **repo_scan_exclusions:** repo's that should be excluded from branch protection policy ,that means the repo's mentioned here are not applied with           branch protection policy.
      3. **repo_policy_overides:** repo owners have an option to override the default policy ,but it requires proper justification then only PR will be             reviewed and approved by GLCP Devops Team

**pull_request_template.py**

1. pull_request_template.py script which is part of productModules folder has the ability to scan all the GLCP Org Repo's and exclude the repo's mentioned under **default**  and **pull_request_template** modules from **github-policies.yaml** **repo_scan_exclusions** list then deploy the pull request template to the final list of repo's.This script will not overrite the PR template if the repo already have an exsisting pull request template.
2.  **pull_request_template**  has the following things
      1. **repo_scan_exclusions:** repo's that should be excluded from pull request enforcement ,that means the repo's mentioned here 
          are not deployed with pull request template.
 
 # branch-protection-reports Folder:
 
 branch-protection-reports contains the text files that are generated by the automation which contains the repo names that has branch protection applied.The file format is "branch-policies-YYYY-MM-DD-HH-MM.txt"
