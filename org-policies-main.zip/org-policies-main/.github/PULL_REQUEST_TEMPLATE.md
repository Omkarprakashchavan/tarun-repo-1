<!--  PR Title Format-->
<!--  Use this format for PR tile: `jira-id: Short and meaningful description`. -->
<!--  Example: `IS-####: Create a pull request template`-->


### Description of Changes
* [ ] Provide business and Technical justification for repos to be excluded from the scan
* [ ] Separate subject from body with a blank line
* [ ] Limit the subject line to 50 characters
* [ ] Capitalize the subject line
