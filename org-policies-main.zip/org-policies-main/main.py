import os
import sys
import yaml
import json
import importlib.util


def main():
    if not 'GIT_HUB_TOKEN' in os.environ:
        print(f'ERROR: Env var "GIT_HUB_TOKEN" must to be set.')
        sys.exit(1)
    
    filename='github-policies.yaml'
    with open(filename, "r") as yaml_file:
        data = yaml.safe_load(yaml_file)
    items=data['modules']
    print(f'github-policies yaml content is: {items}')

    ## IMPORTANT!!!
    # assuming the first item (index 0) in the list is the default exclude list
    # so make sure that the first item in the yaml file is the default exclude list
    default_repo_exclude_list  = items[0]['repo_scan_exclusions']

    # skip index 0 because that's the default exclude list
    for i in items[1:]: # start at index 1 until the end
        module_name=i['name']
        module_description=i['description']
        default_policy=i.get('policy_defaults', [])
        repo_policy_override_list=i.get('repo_policy_overides', [])
        repo_exclude_list=i['repo_scan_exclusions']
        total_exclude_list=[]
        total_exclude_list.extend(default_repo_exclude_list )
        total_exclude_list.extend(repo_exclude_list)
        repo_exclude_list=list(dict.fromkeys(total_exclude_list))
        module=import_module(module_name)
        if default_policy:
           module.main(repo_exclude_list, module_description,module_name,
                        default_policy, repo_policy_override_list)
        else:
           module.main(repo_exclude_list,module_description,module_name)

#This function will load the  specified module dynamically from productModules folder.
def import_module(the_module_name):
    module_dir = 'productModules'
    spec = importlib.util.spec_from_file_location(
              the_module_name, 
              f'''{module_dir}/{the_module_name}.py''')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


main()
