## Managed CI Workflow

This devops managed workflow is designed to be shared by most or all repositories that produce production artifacts.   It consists of a primary workflow that delegates work to a set of reusable workflows within both glcp/managed-ci-workflow and a local project repository.

**NOTE:** Release notes for the managed ci workflows can be [found here](https://hpe.atlassian.net/l/cp/HHHM0mxj). Please refer the release notes for the latest changes

### Where to find help
HPE Internal Slack: #ask-glcp-managed-ci 

### Managed CI Features
Functions managed by managed-ci-workflow:
*  pre-check
    * secret scan
    * malware scanning
    * PR title check
    * copyright check
*  lint
    * also includes code reformatting for languages that support it (ie: SBT/scala)
*  unit tests
*  build
*  post-build
    * ![SonarQube](https://github.com/glcp/devx-sonarqube/tree/main) 
    * SigStore cosign container signing
    * SBOM upload to HPE VTN
 
Functions left to the discretion of project owners:
* pre-stage
* pre-test

![GLCP CI Workflow](https://github.com/glcp/managed-ci-workflow/assets/848327/8eb20368-5299-4605-9bb0-ffac85335fbc)

### Installing the managed CI workflow
1. Create the [non-changing project repository variables](#repository-variables).
2. Create [additional variables](#additional-variables) in .github/mci-variables.yaml
3. Disable current build process or workflows that are triggered by PRs or pushes to main/mainline branch. They would be redundant.
4. Create a fork of glcp/managed-ci-workflow and add a project repository name to the [deployment configuration file](https://github.com/glcp/managed-ci-workflow/blob/main/workflow-deployment.yaml) along with the desired glcp/managed-ci-workflow refspec for glcp/managed-ci-workflow and an *optional_workflows* section if necessary.    See the [deployer instructions](#managed-ci-workflow-deployer) for details.   Open a PR for this fork.   When merged, your project repository will receive all of the workflows specified within the [workflow manifest](https://github.com/glcp/managed-ci-workflow/blob/main/workflow-manifest.yaml) file. Both the primary and template workflows will be copied to under project repo **.github/workflows** folder.
5. If needed, customize the template workflows once they have been deployed to the project repository.

### Repository Variables
All of the reusable workflows are permitted and expected to access [vars from the project repository](https://docs.github.com/en/actions/learn-github-actions/variables#creating-configuration-variables-for-a-repository), and secrets from the project repository or organization.  *Repository variables are considered to be fixed -- they will most likely remain unchanged throughout the life of the repository.*

Create the repository variable **GLCP_BUILD_SYSTEM** by navigating to:

*Repo settings -> Secrets and Variables -> Actions -> Variables -> New repository Variable*

Name the variable "GLCP_BUILD_SYSTEM" and give it one of the following values.   This will be the predominant build system for your project:
* maven
* sbt
* python
* golang

### Additional Variables
Additional variables that influence the build are stored within .github/mci-variables.yaml
These will vary between build systems.
  
  Variables for python system:
  <pre>
  * APP_NAME - repository name within glcp [this may be redundant]
  * APP_ID - APP ID for the project, granted by CCS SRE
  * APP_ID_FIPS - APP ID for the FIPS build of the project
  * BASE_IMAGE - the base image passed to glcp/mci-actions-docker-build-push-app for the Docker App build
  * BASE_IMAGE_FIPS - the base image passed to glcp/mci-actions-docker-build-push-app for the Docker FIPS App build
  * CHANNEL - Feature branches takes the channel from the variable for coreupdate. (For main the channel is fixed to Jenkins-Continuous)
  * DC_PROJECT_NAME - project name for docker-compose
  * DEV_ENV_DIR - checkout directory for glcp/dev-env
  * DEV_ENV_TAG - tag for glcp/dev-env
  * IMAGE_REGISTRIES - A **list** of image registries that require docker login
  * SKIP_AUTOMATION_BUILD - Boolean value to SKIP automation build on repositories that don't need it.
  * VERSION_MAJOR - major number of the generated image tag [default: 2]
  * VERSION_MINOR - minor number of the generated image tag [default: 0]
  * VERSION_OFFSET_MANUAL - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number]
  * VERSION_OFFSET_PR - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number]
  * VERSION_OFFSET_PUSH - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number] </pre>

  For example, .github/mci-variables.yaml has been updated with examples of the values references in python based project repository.
  ```    
  APP_NAME: sample-python-app
  APP_ID: e39b409f-804f-4425-a2ef-16eeb13e6e65
  DEV_ENV_DIR: sample-python-app-dev-env
  DC_PROJECT_NAME: sample-python-app-ci
  DEV_ENV_TAG: "0.0.13"
  SKIP_AUTOMATION_BUILD: true
  VERSION_OFFSET_MANUAL: 100
  VERSION_OFFSET_PR: 200
  VERSION_OFFSET_PUSH: 300
  IMAGE_REGISTRIES:
    - hpeartifacts-glcp-images.jfrog.io
    - quay.io

  ```

  Variables for maven system:
  <pre>
  * APP_NAME - repository name within glcp [this may be redundant]
  * APP_ID - APP ID for the project, granted by CCS SRE
  * BUILD_CONTAINER_IMAGE - name of image to use [ex: quay.io/ccsportal/ubuntu:jammy-openjdk17-ma-202302010240]
  * CHANNEL - Feature branches takes the channel from the variable. (For main the channel is fixed to Jenkins-Continuous)
  * CI_VERSION_PREFIX - prefix version for CI on PR; if not set, defaults to 0.1.0
  * IMAGE_REGISTRY - quay.io/ccsportal/<repo-name>
  * MAVEN_VERSION - version of Maven to download; [default: 3.9.4]
  * SHA_MAVEN_TAR_FILE - SHA of Maven tar file to compare against
  * SKIP_COREUPDATE_PUSH - true or false; if not set, defaults to false
  * SKIP_DOCKER_PUSH - true or false; if not set, defaults to false
  * SKIP_JFROG_PUSH - true or false; if not set, defaults to false
  * VERSION_MAJOR - major number of the generated image tag [default: 2]
  * VERSION_MINOR - minor number of the generated image tag [default: 0]
  * VERSION_OFFSET_MANUAL - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number]
  * VERSION_OFFSET_PR - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number]
  * VERSION_OFFSET_PUSH - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number] 
</pre>

  Variables for golang system:
  <pre>
  * APP_NAME - repository name within glcp [this may be redundant]
  * APP_ID - APP ID for the project, granted by CCS SRE
  * CHANNEL - Feature branches takes the channel from the variable. (For main the channel is fixed to Jenkins-Continuous)
  * GO_VERSION - GO version to be used for the project
  * IMAGE_REGISTRIES - A **list** of image registries that require docker login
  * PRODUCTS - A **list** of dictionary/hash variables that will each generate an artifact.  Group these together where needed:
      * DOCKERFILE_PATH - Dockerfile path for app build [default: docker/Dockerfile]
      * IMAGE_REGISTRY - quay image registry
      * TARGET - Docker target for the build image [default: prod-image]
  * SKIP_COREUPDATE - boolean whether to push to coreupdate or not [Introduced to meet service-identity requirement]
  * SKIP_AUTOMATION_BUILD - Boolean value to SKIP automation build on repositories that don't need it.
  * VERSION - Semantic Major and Minor Version [default: 2.0]
  * VERSION_OFFSET_MANUAL - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number]
  * VERSION_OFFSET_PR - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number]
  * VERSION_OFFSET_PUSH - see <a href="https://github.com/glcp/mci-actions-version-number">details</a> [Optional: needed only when you need to override the version number] </pre>

  For example, .github/mci-variables.yaml has been updated with examples of the values references in go lang based project repository.
  ```
  APP_NAME: sample-go-app
  APP_ID: e39b409f-804f-4425-a2ef-16eeb13e6e65
  GO_VERSION: 1.18
  VERSION: '0.0'
  SKIP_COREUPDATE: true
  SKIP_AUTOMATION_BUILD: true
  CUSTOM_TAG: true
  VERSION_OFFSET_MANUAL: 100
  VERSION_OFFSET_PR: 200
  VERSION_OFFSET_PUSH: 300
  IMAGE_REGISTRIES:
  - hpeartifacts-glcp-images.jfrog.io
  - quay.io
  PRODUCTS:
  - DOCKERFILE_PATH: ./docker/deploy/sim/Dockerfile
    IMAGE_REGISTRY: quay.io/ccsportal/test-app-provision
    TARGET: final
  ```

  Variables for shell script based repos:
  ```
  * APP_NAME - repository name within glcp [this may be redundant]
  * SCRIPT_TO_RUN - trigger script to start the build for script based repos.
  * SCRIPT_ARGS - Arguments for script [default: docker tag from create tag /Optional]
  * VERSION - Semantic Major and Minor Version 
  * IMAGE_REGISTRIES - quay.io/ccsportal
  * DOCKER_PUSH -  boolean to push or skip docker image [default: 1 /Optional]
  ```
  
  Variables for sbt system:
  ```
  * APP_NAME - Repository name within glcp
  * JAVA_VERSION - Java verison to use for scalafmt, verify and build. [default: 1.8]
  ```
 
  For example, .github/mci-variables.yaml has been updated with examples of the values references in Scala based project repository.
  ```    
       APP_NAME: sample-scala-app
       JAVA_VERSION: 1.8
  ```

### Reusable Workflows within a project owner's control
The reusable workflows with prefix "mci-" within .github/workflows are largely boilerplate when installed, with bookend jobs to restore and then preserve the build/test environment.   Workflow-specific steps may be placed between the bookend jobs detailed below.   These "bookends" should not be altered, and the files should not be renamed.

  * pre-stage: .github/workflows/mci-pre-stage.yaml
  * pre-test: .github/workflows/mci-pre-test.yaml


#### Template bookends
An example from mci-pre-stage.yaml

Each of the reusable workflow dependency files (other than the first) begins with two steps that restore a prior environment:
```yaml
    - name: Restore workspace artifacts
      uses: actions/download-artifact@v3
      with:
        name: workspace-artifacts

    - name: Unzip workspace
      run: |
        unzip -oq workspace.zip
        rm workspace.zip
      shell: bash
```
This example restores from the artifact that was created at the end of the pre-check job, then deletes the downloaded zip file.  The artifact itself remains intact and can be downloaded again.

Each reusable workflow file ends with two steps that preserve the workspace.   Files and resources outside of the workspace will not be preserved (i.e. Docker images and running containers):
```yaml
    - name: Zip workspace
      run: |
        zip -rq workspace.zip .
      shell: bash
      
    - name: Preserve directories
      uses: actions/upload-artifact@v3
      with:
        name: workspace-artifacts
        path: workspace.zip
```

#### Reusable workflows outside of a project owner's control
In addition to the project-specific workflows, managed-ci-workflow invokes several reusable workflows that are outside of a project owner's control.  They are hosted within glcp/managed-ci-workflow.
  * pre-check
  * lint
  * unit-test
  * build
  * post-build

### How it works -- and why
Ordinarily a top level workflow might be at least one job each with a set of steps, but steps cannot make use of reusable workflows -- those can only be called as the one and only stage of a job.   As a result, in order to keep things simple at the top level, we implement the managed workflow as a set of jobs.   This does have a few downsides:
1. jobs normally run in parallel, so the jobs at the top level must use "needs:" with the name of the prior job to force them to run in sequence.
2. jobs run within their own environments.   Setting up a development environment in one job will not easily carry over to the subsequent job environments.
   - The workaround: zip (without compression) the entire workspace and upload the zip as an artifact.   Subsequent jobs can download and extract the artifact.
   - While the local workspace is preserved from one job to the next, resources outside of the workspace folder will not be preserved.  Docker resources, for example, will need to be recreated within each job that needs them.

#### Top-level workflow
```yaml
name: Managed CI
on:
  workflow_dispatch:
  pull_request:
  push:
    branches:
      - main
      - master
      - mainline
    tags:
      - '[0-9]+.[0-9]+.[0-9]+'

jobs:
  pre-check:
    uses: glcp/managed-ci-workflow/.github/workflows/mci-pre-check.yaml@v1.1.0
    secrets: inherit
  pre-stage:
    uses: ./.github/workflows/mci-pre-stage.yaml
    secrets: inherit
    needs: pre-check
  lint:
    uses: glcp/managed-ci-workflow/.github/workflows/mci-lint.yaml@v1.1.0
    secrets: inherit
    needs: pre-stage
  pre-test:
    uses: ./.github/workflows/mci-pre-test.yaml
    secrets: inherit
    needs: lint
  unit-test: 
    uses: glcp/managed-ci-workflow/.github/workflows/mci-unit-test.yaml@v1.1.0
    secrets: inherit
    needs: pre-test
  build:
    uses: glcp/managed-ci-workflow/.github/workflows/mci-build.yaml@v1.1.0
    secrets: inherit
    needs: unit-test
  post-build:
    uses: glcp/managed-ci-workflow/.github/workflows/mci-post-build.yaml@v1.1.0
    secrets: inherit
    needs: build
```

### Top level workflows, Managed reusable workflows, Example project-specific reusable workflows
- [Managed reusable workflows](.github/workflows)
- [Top level workflows](workflows/)


## Managed CI Workflow Deployer
In addition to hosting the reusable workflows, glcp/managed-ci-workflow offers the ability to deploy the primary and template workflows to participating repositories.   

Versioning is supported for these workflows and for the workflow file manifest.    To create a new version for the workflows within this repository:
- Modify, commit, and push the workflow changes
- Create and push a new tag ("git tag <TAG> && git push origin <TAG>") or a new branch
- For primary, optional, or template workflows (those distributed to remote repositories) reference the tag or branch within the workflow deployment config *workflow-deployments.yaml* as described below
- For reusable workflows (hosted within glcp/managed-ci-workflow) reference the tag or branch within the primary workflow itself

### Workflow file manifest
The workflow file names are contained within *workflow-manifest.yaml* as lists within *primary-workflows*, *optional-workflows*, and *template-workflows* sections, as shown below:
```yaml
primary_workflows:
  - managed-ci-merge.yaml
  - managed-ci-pr.yaml
  - managed-ci-manual-build.yaml
  - managed-ci-pr-ft.yaml
optional_workflows:
  - managed-ci-hotfix-branch-create.yaml
template_workflows:
  - mci-pre-stage.yaml
  - mci-pre-test.yaml
```
The contents of this file may change over time and should have an associated tag when it does.  The tag can be referenced within *workflow-deployments.yaml*

### Workflow Deployment configuration
As with glcp/org-policies, the configuration is indended to be modular -- but for the present only supports the *managed-ci-workflow* module.
The contents of the *repositories* list should be the only section that requires updates.

#### Repositories
The repositories list supports the keys:
- *name* - the name of the repository (within the glcp organization) to which the deployer will push workflows described within the manifest.
- *refspec* - a refspec for glcp/managed-ci-workflow (tag, branch, commit sha, etc.)
- *optional_workflows* - an optional key that contains a list of workflows (from the *optional_workflows* list within the manifest) that the participating repository would like to have installed.    These are workflows that are centrally managed but not manditory.   Hotfix workflows are an example.

```yaml
modules:
  - name: managed-ci-workflow
    description: Managed CI Workflow
    repositories:
      - name: rmcnamara-managed-ci-workflow-test
        refspec: tags/v1.0.0
      - name: rmcnamara-firmware-registry
        refspec: tags/v1.0.0
      - name: managed-ci-workflow-test-python
        refspec: main
        optional_workflows:
          - managed-ci-hotfix-branch-create.yaml
```
# What happens in the workflow?

# 1. For python based application in GLCP
# Triggers:
  The Workflow has 3 Triggers which are **workflow_dispatch** to enable developers to execute the workflow in feature branches, **pull_request** to enable the workflow to get triggered when a PR is opened, **push** to enable the workflow to trigger on merge to deafult_branch or when a release tag is created.

| _Trigger_             | _Description_                                                                                             |
|:----------------------|:----------------------------------------------------------------------------------------------------------|
| **workflow_dispatch** | To enable the teams make use of the Managed CI workflow in feature/non-default branches for manual CI     |
| **pull_request**      | To trigger the Managed CI workflow when a PR is opened, updated.                                          |
| **push**              | [branch: main, master, mainline]: To Trigger the Managed CI workfow when PR is merged to default branch.<br>[tags: [0-9]+.[0-9]+.[0-9]+]: To Trigger the Managed CI workfow when a tag is created for the release |

# pre-check:
  The validation of the CI is done on pre-check. The workflow used for the execution of pre-check is ![mci-pre-check.yaml](.github/workflows/mci-pre-check.yaml). For python based application the **secret-scanner, mci-python** jobs are triggered.

The jobs that are executed for python based application on pre-check
| _Jobs_             | _Description_                                                                  |
|--------------------|--------------------------------------------------------------------------------|
| **secret-scanner** | Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner. |
| **mci-python**     | python job is intended for application based on **python**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python'**].|

## 1. secret-scanner:
  Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner.
  The workflow used for the execution of secret-scanner is ![scanning-workflow.yml](https://github.com/glcp/Secret-Scan-Tool/blob/main/.github/workflows/scanning-workflow.yml)

### Deafult Inputs for secret-scan
| _Input_             | _Default_                               | _Description_                                                       | _Required_  |
|:-------------------:|:----------------------------------------|:--------------------------------------------------------------------|:------------|
| repo                | ```${{github.event.repository.name}}``` | Name of the repository where secret scan need to be executed        | true        |
| branch              | ```${{github.ref_name}}```              | Branch in which secret-scan need to be executed on the given repo   | true        |

## 2. malware-scanner:
  Malware Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the malware in the repo on a Pull Request and reports it in the comments of the PR. if any malware is found the workflow will fail. The scan summary is reported to the comments of the PR irrespective of the result of the scan.
  The workflow used for the execution of malware-scanner is ![malware scan workflow](.github/workflows/mci-clamav.yaml). There is no varaiable or parameter needed for this worklow.

## 3. mci-python:
The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python'**]. 

  **when the conditions are satisfied the job does the following actions in order.**

  |   | _description_                          | _actions_                                                                             | _execution_                          |
  |:-:|:---------------------------------------|:--------------------------------------------------------------------------------------|:-------------------------------------|
  | 1 | Clone the Repository                   |  ```actions/checkout@v3.3.0```                                                        | The step is executed on all triggers |
  | 2 | set-environment variables for the job. | ```actions-tools/yaml-outputs@v2```                                                   | The step is executed on all triggers |
  | 3 | PR title validation                    |  ```glcp/mci-actions-pr-title-validation@v1.0```                                      | The step is executed only on PR |
  | 4 | Cloning CCS DEV Environment repository | ```actions/checkout@v3.3.0```                                                         | The step is executed on all triggers |
  | 5 | Cloning the application repository     | ```actions/checkout@v3.3.0```                                                         | The step is executed on all triggers |
  | 6 | Cloning the CCS automation repository  | ```actions/checkout@v3.3.0```                                                         | The step is executed on all triggers |
  | 7 | zip and upload artifacts with names workspace and workspace-clean-artifacts to use them in future jobs | ```actions/upload-artifact@v3``` | The step is executed on all triggers |

### Inputs/Secrets for mci-python
| _Input_            | _Default_                                   | _Description_                                                    | _Required_ |
|:-------------------|:--------------------------------------------|:-----------------------------------------------------------------|:---------- |
| pull_request_title | ```${{ github.event.pull_request.title }``` | The title of PR                                                  | true       |
| jira_user          | ```${{ secrets.CCS_JIRA_USER }}```          | User to connect HPE JIRA                                         | true       |
| jira_apikey        | ```${{ secrets.CCS_JIRA_APIKEY }}```        | API Key to connect HPE JIRA                                      | true       |
| gh_token           | ```${{ env.GITHUB_APP_TOKEN }}```          | Github Token                                                     | true       |
| DEV_ENV_TAG        | ```${{ env.DEV_ENV_TAG }}```                | Tag/Reference used to clone the glcp/dev-env repository          | false      |
| DEV_ENV_DIR        | ```${{ env.DEV_ENV_DIR }}```                | Path to which glcp/dev-env repository is cloned                  | true       |
| APP_NAME           | ```${{ env.APP_NAME }}```                   | Application Name, Usually same as the repository name            | true       |

# pre-stage:
The pre-stage job depends on the pre-check job. The pre-stage workflow need/will be in the application repository **.github/workflows** folder. This is just a boilerplate workflow, which the application team can use to execute project specific jobs before Lint that cann't be incorporated in MANAGED CI. The reference workflow for pre-stage is ![mci-pre-stage.yaml](templates/mci-pre-stage.yaml)

# lint:
Lint job depends on pre-stage job and is executed only on PR. The workflow that is used for the execution of lint ![mci-lint.yaml](.github/workflows/mci-lint.yaml). For python based application the **mci-python** job is triggered.

## 1. mci-python:
The lint job is configured to be executed only on PR. The job is executed based on the conditions provided in **Repository Variables**, **if: vars.GLCP_BUILD_SYSTEM == 'python' && github.event_name == 'pull_request'**.

**when the conditions are satisfied the job does the following actions.**

|   | _Description_                                                     | _Actions_                                     | _Execution_                     |
|:-:|:------------------------------------------------------------------|:----------------------------------------------|:--------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job   | ```actions/download-artifact@v3```            | The step is executed only on PR |
| 2 | set-environment variables for the job.                            | ```actions-tools/yaml-outputs@v2```           | The step is executed only on PR |
| 3 | Login to Quay Container Registry                                  | ```docker/login-action@v1```                  | The step is executed only on PR |
| 4 | BootStrap Dev Environment to perform Linting                      | ```glcp/mci-actions-bootstrap-dev-env@v1.0``` | The step is executed only on PR |
| 5 | Linting for Python                                                | Executed using bash commands as  in ```5*```  | The step is executed only on PR |
| 6 | zip and upload artifacts to workspace to use them in future jobs  | ```actions/upload-artifact@v3```              | The step is executed only on PR |

  5*. Linting using
  ```yaml
    - name: Lint
      id: lint
      shell: bash
      run: |
          cd $GITHUB_WORKSPACE/${{ env.DEV_ENV_DIR }}
          #!/bin/bash -x
          ws/${{ env.APP_NAME }}/automation/ci/run-in-ccs-dev.sh \
            ${{ env.DC_PROJECT_NAME }} \
            poetry run scripts/lint.sh
  ```
All applications based on python on-boarded to Managed CI need to have lint.sh script available in scripts folder of their repositories.

### Inputs/Secrets for mci-python
| _Input_                | _Default_                                                | _Description_                                         | _Required_ |
|:-----------------------|:---------------------------------------------------------|:------------------------------------------------------|:---------- |
| username/quay_username | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                         | true       |
| password/quay_password | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                         | true       |
| DEV_ENV_DIR            | ```${{ env.DEV_ENV_DIR }}```                             | Path to which glcp/dev-env repository is cloned       | true       |  
| DC_PROJECT_NAME        | ```${{ env.DC_PROJECT_NAME }}```                         | Name of the project                                   | true       |
| jfrog_user             | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                        | true       |
| jfrog_passwd           | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                        | true       |
| devenv_tag             |  ```${{ env.DEV_ENV_TAG }}```                            | glcp/dev-env version                                  | true       |
| APP_NAME               | ```${{ env.APP_NAME }}```                                | Application Name, Usually same as the repository name | true       |

# pre-test:
The pre-test job depends on the lint job. The pre-test workflow need/will be in the repository **.github/workflows** folder. This is just a boilerplate workflow, which is the application team can use to execute project specific jobs before unit-test that cann't be incorporated in MANAGED CI. The reference workflow for pre-test is ![mci-pre-test.yaml](templates/mci-pre-test.yaml)

# unit-test:
The unit-test depends on pre-test job. unit-test workflow has 4 main jobs **mci-maven, mci-python, mci-golang, mci-sbt** which are executed during all 3 triggers. The workflow that is used for the execution of lint ![mci-unit-test.yaml](.github/workflows/mci-unit-test.yaml). For python based application the **mci-python** job is triggered and **mci-maven, mci-golang, mci-sbt** are skipped.

## 1. mci-python:
  mci-python job is intended for application based on **python**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python'**]. 

  **when the conditions are satisfied the job does the following actions.**

  |    | _Description_                                                            | _Actions_                                               | _Executions_                         |
  |:--:|:-------------------------------------------------------------------------|:--------------------------------------------------------|:-------------------------------------|
  | 1  | Download and unzip workspace artifacts uploaded in previous job          | ```actions/download-artifact@v3```                      | The step is executed on all triggers |
  | 2  | set-environment variables for the job.                                   | ```actions-tools/yaml-outputs@v2```                     | The step is executed on all triggers |
  | 3  | Login to Quay Container Registry                                         | ```docker/login-action@v1```                            | The step is executed on all triggers |
  | 4  | BootStrap Dev Environment to perform Linting                             | ```glcp/mci-actions-bootstrap-dev-env@v1.0```           | The step is executed on all triggers |
  | 5* | Executing test script using poetry                                       | Executed using bash commands as given in ```6*```       | The step is executed on all triggers |
  | 6  | zip and upload artifacts with names workspace to use them in future jobs | ```actions/upload-artifact@v3```                        | The step is executed on all triggers |

  6*. Executing unit-test using poetry. All Application based on python should have their test script named unit-test.sh in the scripts folder of their repository
  ```yaml
    - name: Unit Tests
      id: unit_tests
      shell: bash
      run: |
        cd $GITHUB_WORKSPACE/${{ env.DEV_ENV_DIR }}
        ws/${{ env.APP_NAME }}/automation/ci/run-in-ccs-dev.sh \
            ${{ env.DC_PROJECT_NAME }} \
          poetry run ${{ steps.testscript.outputs.TEST_SCRIPT }}
  ```
### Inputs/Secrets for mci-python
| _Input_                 | _Default_                                                 | _Description_                                         | _Required_ |
|:------------------------|:----------------------------------------------------------|:------------------------------------------------------|:---------- |
| username/quay_username  | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```           | Quay Username                                         | true       |
| password/quay_password  | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}```  | Quay Password                                         | true       |
| DEV_ENV_DIR             | ```${{ env.DEV_ENV_DIR }}```                              | Path to which glcp/dev-env repository is cloned       | true       |
| DC_PROJECT_NAME         | ```${{ env.DC_PROJECT_NAME }}```                          | Name of the project                                   | true       |
| jfrog_user              | ```${{ secrets.CCS_JFROG_USERNAME }}```                   | JFROG Username                                        | true       |
| jfrog_passwd            | ```${{ secrets.CCS_JFROG_PASSWORD }}```                   | JFROG password                                        | true       |
| devenv_tag              |  ```${{ env.DEV_ENV_TAG }}```                             | glcp/dev-env version                                  | true       |
| APP_NAME                | ```${{ env.APP_NAME }}```                                 | Application Name, Usually same as the repository name | true       |
| gh_token                | ```${{ env.GITHUB_APP_TOKEN }}```                        | Github Token                                          | true       |

# build:
build depends on unit-test job. Build is executed during all 3 triggers based on the conditions. The workflow that is used for the execution of build ![mci-build.yaml](.github/workflows/mci-build.yaml). For python based application the **mci-python** job is triggered. 

## 1. mci-python
  Building or packaging of the artifacts for python based applications in GLCP are done using the workflow ![mci-build-python.yaml](.github/workflows/mci-build-python.yaml). The workflow is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python'**]. The Jobs executed by mci-build-python.yaml are **create-tag, build-pr, build-app, build-automation, coreupdate, jira_update**.

### a. create-tag 
The tag for the build is determinied and set as output using the create-tag job. the create-tag is executed on all trigger events.

**The following steps are executed in order in create-tag job**.
  |   | _description_                          | _actions_                                              | 
  |:-:|:---------------------------------------|:-------------------------------------------------------|
  | 1 | Cloning the application repository     | ```actions/checkout@v3.3.0```                          |
  | 2 | set-environment variables for the job. | ```actions-tools/yaml-outputs@v2```                    | 
  | 3 | Assemble Git Tag                       | Step Executed using bash commands as given in ```3*``` | 

3* . Assemble Git Tag
```yaml
    - name: Assemble Git Tag
      id: tag_version
      shell: bash
      run: |
        MAJOR="2"
        MINOR="0"
        if [[ "${{ env.VERSION_MAJOR }}" != "" ]]; then MAJOR=${{ env.VERSION_MAJOR }}; fi
        if [[ "${{ env.VERSION_MINOR }}" != "" ]]; then MINOR=${{ env.VERSION_MINOR }}; fi
        if [[ "${{ github.event_name }}" == "push" && "${{ github.ref_name }}" == "${{ github.event.repository.default_branch }}" ]]; then
          export tag="${MAJOR}.${{ github.run_number }}.${MINOR}"
          git tag $tag
          git push --tags
        else
          export tag="${MAJOR}.${{ github.run_number }}.${MINOR}-dev"
        fi
        echo "Git Tag version: $tag"
        echo "tag=$tag" >> $GITHUB_OUTPUT
```

### b. build-pr
  The build-pr job is executed only on PR.

**The following steps are executed in order in build-pr when the conditions are satisfied.**
  |   | _description_                           | _actions_                                                            | 
  |:-:|:----------------------------------------|:---------------------------------------------------------------------|
  | 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```                                        |
  | 2 | set-environment variables for the job.  | ```actions-tools/yaml-outputs@v2```                                  | 
  | 3 | login yo quay                           | ```docker/login-action@v1```                                         | 
  | 4 | Docker build without fips               | A test build is done on PR using docker command as given in ```4*``` |
  | 5 | Docker build with FIPS                  | A test build is done on PR using docker command as given in ```5*``` |

  4*. Docker Build without fips
```yaml
    - name: Docker Build
      id: build
      shell: bash
      run: |
          # cd $GITHUB_WORKSPACE/$DEV_ENV_DIR/ws/${APP_NAME}
          #!/bin/bash -x
          
          echo "Running CI build with environment variables:"
          export -p | sed 's/declare -x //'
          docker build \
            --no-cache \
            --pull \
            --force-rm \
            --file docker/Dockerfile \
            --build-arg JFROG_USERNAME=${{ secrets.CCS_JFROG_USERNAME }} \
            --build-arg JFROG_PASSWORD=${{ secrets.CCS_JFROG_PASSWORD }} \
            --build-arg BASE_IMAGE=${{ env.BASE_IMAGE }} \
            --tag ci_image:${{ env.APP_NAME }} \
            --target ci-stage \
            .
```
  5*. Docker build with FIPS is only executed when BASE_IMAGE_FIPS exists else will be skipped
```yaml
    - name: Docker Build Base Image with FIPS
      if: env.BASE_IMAGE_FIPS != ''
      id: build_with_fips
      shell: bash
      run: |
        # cd $GITHUB_WORKSPACE/$DEV_ENV_DIR/ws/$APP_NAME
        #!/bin/bash -x
        
        echo "Running CI build with environment variables:"
        export -p | sed 's/declare -x //'
        docker build \
          --no-cache \
          --pull \
          --force-rm \
          --file docker/Dockerfile \
          --build-arg JFROG_USERNAME=${{ secrets.CCS_JFROG_USERNAME }} \
          --build-arg JFROG_PASSWORD=${{ secrets.CCS_JFROG_PASSWORD }} \
          --build-arg BASE_IMAGE=${{ env.BASE_IMAGE_FIPS }} \
          --tag ci_image:${{ env.APP_NAME }} \
          --target ci-stage \
          . 
```

### c. build-app
  The build-app job is used for the app build and will be triggered only on workflow dispatch or push.

**The following stpes are executed in order.**
  |   | _description_                           | _actions_                                                         | _Execution_                                         |
  |:-:|:----------------------------------------|:------------------------------------------------------------------|-----------------------------------------------------|
  | 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```                                     | executed on workflow_dispatch or push               |
  | 2 | set-environment variables for the job.  | ```actions-tools/yaml-outputs@v2```                               | executed on workflow_dispatch or push               |
  | 3 | Docker build without fips               | ```glcp/mci-actions-docker-build-push-app@v1.0```                 | executed on workflow_dispatch or push               |
  | 4 | Docker build with FIPS                  | ```glcp/mci-actions-docker-build-push-app@v1.0```                 | executed on workflow_dispatch or push and  BASE_IMAGE_FIPS is not null |

#### Inputs/Secrets for mci-python

| _Input_        | _Default_                                                | _Description_                                                       | _Required_  |
|:---------------|:---------------------------------------------------------|:--------------------------------------------------------------------|:------------|
| APP_NAME       | ```${{ env.APP_NAME }}```                                | Application name in coreupdate, Usually same as the repository name | true        |
| APP_ID         | ```${{ env.APP_ID }}```                                  | Coreupdate Application ID                                           | true        |
| quay_username  | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                                       | true        |
| quay_password  | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                                       | true        |
| jfrog_username | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                                      | true        |
| jfrog_password | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                                      | true        |
| base_image     | ```without fips: ${{ env.BASE_IMAGE }}```<br>```with fips:${{ env.BASE_IMAGE_FIPS }}``` | glcp/dev-env version                 | false       |
| gh_token       | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                                                        | true        |

### d. build-automation
  The build-automation job is used for the automation build and will be triggered only on workflow dispatch or push.

The following stpes are executed in order.
  |   | _description_                           | _actions_                                                               |
  |:-:|:----------------------------------------|:------------------------------------------------------------------------|
  | 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```                                           |
  | 2 | set-environment variables for the job.  | ```actions-tools/yaml-outputs@v2```                                     |
  | 3 | Docker build                            | ```glcp/mci-actions-docker-build-push-automation@v1.0```                |

#### Inputs/Secrets for build-automation 

| _Input_        | _Default_                                                | _Description_                                                       | _Required_ |
|:---------------|:---------------------------------------------------------|:--------------------------------------------------------------------|:---------- |
| APP_NAME       | ```${{ env.APP_NAME }}```                                | Application name in coreupdate, Usually same as the repository name | true       |
| APP_ID         | ```${{ env.APP_ID }}```                                  | Coreupdate Application ID                                           | true       |
| quay_username  | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                                       | true       |
| quay_password  | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                                       | true       |
| jfrog_username | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                                      | true       |
| jfrog_password | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                                      | true       |
| gh_token       | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                                                        | true       |

### e. coreupdate
  The coreupdate job is used to update the channel versions in Coreupdate.

The following stpes are executed in order.
  |   | _description_                           | _actions_                                                           |
  |:-:|:----------------------------------------|:------------------------------------                                |
  | 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```                                       |
  | 2 | set-environment variables for the job.  | ```actions-tools/yaml-outputs@v2```                                 |
  | 3 | set coreupdate channel                  | coreupdate channel is set as output using bash conditional ```3*``` |
  | 4 | coreupdate push                         | ```glcp/mci-actions-coreupdate@v1.0```                              |
  | 5 | coreupdate push with fips               | ```glcp/mci-actions-coreupdate@v1.0```                              |

3*. Determinig the channel for core update
```yaml
    - name: Channel
      id: channel
      shell: bash
      run: |
        CHANNEL=""
        if [[ "${{ github.event_name }}" == "workflow_dispatch" ]]; then CHANNEL="${{env.CHANNEL}}"; fi
        if [[ "${{ github.event_name }}" == "push" && "${{ github.ref_name }}" == "${{ github.event.repository.default_branch }}" ]]; then CHANNEL="Jenkins-Continuous"; fi
        echo "channel=$CHANNEL" >> $GITHUB_OUTPUT
        echo "Channel: $CHANNEL"
```

#### Inputs/Secrets for coreupdate

| _Input_            | _Default_                                                | _Description_                                                       | _Required_ |
|:-------------------|:---------------------------------------------------------|:--------------------------------------------------------------------|:---------- |
| APP_NAME           | ```${{ env.APP_NAME }}```                                | Application name in coreupdate, Usually same as the repository name | true       |
| APP_ID             | ```${{ env.APP_ID }}```                                  | Coreupdate Application ID                                           | true       |
| quay_username      | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                                       | true       |
| quay_password      | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                                       | true       |
| jfrog_username     | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                                      | true       |
| jfrog_password     | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                                      | true       |
| UPDATECTL_USER     | ```${{ secrets.CCS_UPDATECTL_USER }}```                  |  updatectl user                                                     | true       |
| UPDATECTL_SERVER   | ```${{ secrets.CCS_UPDATECTL_SERVER }}```                |  updatectl server                                                   | true       |
| UPDATECTL_KEY      | ```${{ secrets.CCS_UPDATECTL_KEY }}```                   |  updatectl password                                                 | true       |
| COREROLLER_USER    | ```${{ secrets.CCS_COREROLLER_USER }}```                 | coreroller user                                                     | true       |
| COREROLLER_SERVER  | ```${{ secrets.CCS_COREROLLER_SERVER }}```               | coreroller server                                                   | true       |
| COREROLLER_KEY     | ```${{ secrets.CCS_COREROLLER_KEY }}```                  | coreroller password                                                 | true       |
| gh_token           | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                                                        | true       |

### f. jira_update
  The jira update job is used to update the jira ticket with build tag. It uses the following action ```glcp/mci-actions-jiraupdate@v1.0```

# post-build:
post-build depends on build job and is executed during all 3 triggers. The workflow that is used for the execution of post-build ![mci-post-build.yaml](.github/workflows/mci-post-build.yaml). For python based application the **sonar-python, set-matrix-variables, sbom-upload** jobs are triggered. 

## 1. sonar-python 
The sonar-python job is triggered on all trigger events. It performs the code quality analysis and check the quality gate status. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python'**] 

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                     | _Actions_                                     | _Execution_                          |
|:-:|:------------------------------------------------------------------|:----------------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job   | ```actions/download-artifact@v3```            | The step is executed on all triggers |
| 2 | set-environment variables for the job.                            | ```actions-tools/yaml-outputs@v2```           | The step is executed on all triggers |
| 3 | Override Python Coverage Source Path for Sonar                    | Executed using bash commands ```3*```         | The step is executed on all triggers |
| 4 | Sonar Scan on the repository                                      | ```hpe-actions/sonarqube-scan@main```         | The step is executed on all triggers |



3*. Override Python Coverage Source Path for Sonar
```yaml
      - name: Override Python Coverage Source Path for Sonar
        shell: bash
        run: |
          file=$(find . -name coverage.xml -print)
          sed -i -e "s,<source>.*</source>,<source>/github/workspace/${{env.DEV_ENV_DIR}}/ws/${{env.APP_NAME}}/app/</source>,g" $file
```

## 2. set-matrix-variables
The job is used to seup matrix output for sbom-upload matrix startegy.

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                     | _Actions_                                     | _Execution_                          |
|:-:|:------------------------------------------------------------------|:----------------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job   | ```actions/download-artifact@v3```            | The step is executed on all triggers |
| 2 | set-environment variables for the job.                            | ```actions-tools/yaml-outputs@v2```           | The step is executed on all triggers |
| 3 | ste-matrix JSON output                                            | Executed using bash commands ```3*```         | The step is executed on all triggers |

  3*. set matrix JSON output
```yaml
  - id: set-matrix
    run: echo "::set-output name=matrix::{\"include\":[{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL1 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME1 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL2 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME2 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL3 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME3 }}\"}]}"

```

## 3. sbom-upload
To enable SBOM generation and upload to VTN, the inputs are like project name (reponame),product-name(docker image name), product-version and dist-list are required. Create a branch of glcp/managed-ci-workflow and update VTN config from [vtn-config.yaml.](https://github.com/glcp/managed-ci-workflow/blob/main/utils/vtn-config.yaml) then create a PR to the main branch. Here is the example of values to create the PR. 
```yaml
 
Projects:
  - name: 'platform-analytics-ingest-etl'
    product-name: 'platform-analytics-ingest-etl'
    product-version: '1.0.0'
    dist-list: 'giotto-devops'
``` 
Sbom generation and upload to VTN is done from the runner label "managed-ci-vtn". The action it uses is glcp/managed-ci-workflow/actions/upload-sbom@2.0.0 which internally uses "hpe-actions/cosign@v3" action for signing and to upload the sbom to VTN.
The job performs the cosign, verify and uploading sbom to VTN. The job is executed only on default_branch(main/mainline/master)

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                   | _Actions_                                     | _Execution_                                 |
|:-:|:----------------------------------------------------------------|:----------------------------------------------|:--------------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job | ```actions/download-artifact@v3```            | The step is executed on only default branch |
| 2 | set-environment variables for the job.                          | ```actions-tools/yaml-outputs@v2```           | The step is executed on only default branch |
| 3 | Docker Login to jfrog artifactory                               | ```docker/login-action@v2```                  | The step is executed on only default branch |
| 4 | Docker Login to quay                                            | ```docker/login-action@v2```                  | The step is executed on only default branch |
| 5 | Cosign verify and upload sbom                   | ```glcp/managed-ci-workflow/actions/upload-sbom@sbom_upload```| The step is executed on only default branch |
 

# 2. For java based application using maven build tool in GLCP
# Triggers:
  The Workflow has 3 Triggers which are **workflow_dispatch** to enable developers to execute the workflow in feature branches, **pull_request** to enable the workflow to get triggered when a PR is opened, **push** to enable the workflow to trigger on merge to deafult_branch or when a release tag is created.

| _Trigger_             | _Description_                                                                                             |
|:----------------------|:----------------------------------------------------------------------------------------------------------|
| **workflow_dispatch** | To enable the teams make use of the Managed CI workflow in feature/non-default branches for manual CI     |
| **pull_request**      | To trigger the Managed CI workflow when a PR is opened, updated.                                          |
| **push**              | [branch: main, master, mainline]: To Trigger the Managed CI workfow when PR is merged to default branch.<br>[tags: [0-9]+.[0-9]+.[0-9]+]: To Trigger the Managed CI workfow when a tag is created for the release |

# pre-check:
  The validation of the CI is done on pre-check. The workflow used for the execution of pre-check is ![mci-pre-check.yaml](.github/workflows/mci-pre-check.yaml). For java based application the **secret-scanner, mci-maven** jobs are triggered.

**The jobs that are executed for java based application using maven build tool on pre-check**
| _Jobs_             | _Description_                                                                  |
|--------------------|--------------------------------------------------------------------------------|
| **secret-scanner** | Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner. |
| **malware-scanner** | Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner. |
| **mci-maven**     | mci-maven job is intended for application based on **maven**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'maven'**].|

## 1. secret-scanner:
  Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner.
  The workflow used for the execution of secret-scanner is ![scanning-workflow.yml](https://github.com/glcp/Secret-Scan-Tool/blob/main/.github/workflows/scanning-workflow.yml)

### Deafult Inputs for secret-scan
| _Input_             | _Default_                               | _Description_                                                       | _Required_  |
|:-------------------:|:----------------------------------------|:--------------------------------------------------------------------|:------------|
| repo                | ```${{github.event.repository.name}}``` | Name of the repository where secret scan need to be executed        | true        |
| branch              | ```${{github.ref_name}}```              | Branch in which secret-scan need to be executed on the given repo   | true        |

## 2. mci-maven:
The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'maven'**]. 

  **when the conditions are satisfied the job does the following actions in order.**

  |   | _description_                                                                                          | _actions_                                                      | _execution_                          |
  |:-:|:-------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------|:-------------------------------------|
  | 1 | Clone the Repository                                                                                   | ```actions/checkout@v3.3.0```                                  | The step is executed on all triggers |
  | 2 | set-environment variables for the job.                                                                 | ```actions-tools/yaml-outputs@v2```                            | The step is executed on all triggers |
  | 3 | Validate / Add Ticket to PR Title                                                                      | ```glcp/ccs-automation/ci_cd_commons/pr_title_validation@v2``` | The step is executed only on PR      |
  | 4 | zip and upload artifacts with names workspace and workspace-clean-artifacts to use them in future jobs | ```actions/upload-artifact@v3```                               | The step is executed on all triggers |

### Inputs/Secrets for mci-maven
| _Input_            | _Default_                                   | _Description_               | _Required_ |
|:-------------------|:--------------------------------------------|:----------------------------|:-----------|
| pull_request_title | ```${{ github.event.pull_request.title }``` | The title of PR             | true       |
| jira_user          | ```${{ secrets.CCS_JIRA_USER }}```          | User to connect HPE JIRA    | true       |
| jira_apikey        | ```${{ secrets.CCS_JIRA_APIKEY }}```        | API Key to connect HPE JIRA | true       |
| gh_token           | ```${{ env.GITHUB_APP_TOKEN }}```          | Github Token                | true       |

# pre-stage:
The pre-stage job depends on the pre-check job. The pre-stage workflow need/will be in the application repository **.github/workflows** folder. This is just a boilerplate workflow, which the application team can use to execute project specific jobs before Lint that cann't be incorporated in MANAGED CI. The reference workflow for pre-stage is ![mci-pre-stage.yaml](templates/mci-pre-stage.yaml)

# lint:
Lint job depends on pre-stage job and is executed only on PR. The workflow that is used for the execution of lint ![mci-lint.yaml](.github/workflows/mci-lint.yaml). For java based application the **mci-maven** job is triggered.

## 1. mci-maven:
The lint job is configured to be executed only on PR. The job is executed based on the conditions provided in **Repository Variables**, **if: vars.GLCP_BUILD_SYSTEM == 'maven' && github.event_name == 'pull_request'**.

**when the conditions are satisfied the job does the following actions.**

|   | _Description_                                                     | _Actions_                                     | _Execution_                     |
|:-:|:------------------------------------------------------------------|:----------------------------------------------|:--------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job   | ```glcp/mci-actions-workspace-restore@v1```   | The step is executed only on PR |
| 2 | set-environment variables for the job.                            | ```glcp/mci-actions-variables-restore@v2```   | The step is executed only on PR |
| 3 | Linting for Java                                                  | ```super-linter/super-linter/slim@v5```       | The step is executed only on PR |
| 6 | zip and upload artifacts to workspace to use them in future jobs  | ```glcp/mci-actions-workspace-backup@v1```    | The step is executed only on PR |

### Inputs/Secrets for mci-maven
| _Input_               | _Default_                                         | _Description_                                                                                                                                                      | _Required_ |
|:----------------------|:--------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-----------|
| VALIDATE_ALL_CODEBASE | ```false```                                       | Will parse the entire repository and find all files to validate across all types. NOTE: When set to false, only new or edited files will be parsed for validation. | true       |
| DEFAULT_BRANCH        | ```${{github.event.repository.default_branch}}``` | The branch to run against                                                                                                                                          | true       |
| GITHUB_TOKEN          | ```${{ secrets.GITHUB_TOKEN }}```                 | The GitHub token                                                                                                                                                   | true       |

# pre-test:
The pre-test job depends on the lint job. The pre-test workflow need/will be in the repository **.github/workflows** folder. This is just a boilerplate workflow, which is the application team can use to execute project specific jobs before unit-test that cann't be incorporated in MANAGED CI. The reference workflow for pre-test is ![mci-pre-test.yaml](templates/mci-pre-test.yaml)

# unit-test:
The unit-test depends on pre-test job is executed during all 3 triggers. The workflow that is used for the execution of unit-test ![mci-unit-test.yaml](.github/workflows/mci-unit-test.yaml). For java based application the **mci-maven** job is triggered.

## 1. get-docker-image-name:
  This job runs to get the Docker container image name from the variable
  `BUILD_CONTAINER_IMAGE` in the `.github/mci-variables.yaml`
  and sets an output variable that the `mci-maven` job will use.
  Example value for `BUILD_CONTAINER_IMAGE` is `quay.io/ccsportal/ubuntu:jammy-openjdk17-ma-202302010240`

## 2. mci-maven:
  mci-maven job is intended for application based on **maven**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'maven'**]. 

**when the conditions are satisfied the job does the following actions.**

|     | _Description_                                                            | _Actions_                                   | _Executions_                                        |
|:---:|:-------------------------------------------------------------------------|:--------------------------------------------|:----------------------------------------------------|
|  1  | Download and unzip workspace artifacts uploaded in previous job          | ```glcp/mci-actions-workspace-restore@v1``` | The step is executed on all triggers                |
|  2  | Set environment variables for the job.                                   | ```glcp/mci-actions-variables-restore@v2``` | The step is executed on all triggers                |
| 3*  | Install dependencies                                                     | Execute `./install-dependencies.sh`         | The step is executed on all triggers                |
|  4  | Set environment variable VERSION_NUMBER                                  | ```glcp/mci-actions-version-number@v1```    | The step is executed on all triggers                |
|  5  | Assemble Git Tag                                                         | ```glcp/mci-actions-version-tag/java@v1```  | The step is executed on all triggers                |
|  6  | Unit Tests                                                               | Execute `build_ut.sh`                       | The step is executed on all triggers                |
| 7*  | SonarQube Scan                                                           | ```hpe-actions/sonarqube-scan@main```       | The step is executed on all triggers                |
| 8*  | Push to Jfrog                                                            | See commands in section `8*` below          | The step is executed only on push to default branch |
| 9*  | OWASP Dependency-Check                                                   | See commands in section `9*` below          | The step is executed only on push to default branch |
| 10* | Upload Dependency-Check report                                           | See commands in section `9*` below          | The step is executed only on push to default branch |
| 11  | zip and upload artifacts with names workspace to use them in future jobs | ```actions/upload-artifact@v3```            | The step is executed on all triggers                |

3*. The `install-dependencies.sh` should contain whatever commands are needed to ensure
that the unit tests will run without any errors.  Example:
```shell
#!/bin/bash -ex

# The MAVEN_VERSION and SHA_MAVEN_TAR_FILE env vars should be set in 
# the .github/mci-variables.yaml file.

echo "MAVEN_VERSION is $MAVEN_VERSION"
echo "SHA_MAVEN_TAR_FILE is $SHA_MAVEN_TAR_FILE"

# if MAVEN_VERSION not set, then use default values:
if [ -z "$MAVEN_VERSION" ]; then
    export MAVEN_VERSION=3.9.4
    export SHA=deaa39e16b2cf20f8cd7d232a1306344f04020e1f0fb28d35492606f647a60fe729cc40d3cba33e093a17aed41bd161fe1240556d0f1b80e773abd408686217e
    echo "WARNING: env var MAVEN_VERSION is NOT set... defaulting to MAVEN_VERSION=$MAVEN_VERSION"
else
# MAVEN_VERSION is set.  Check if SHA_MAVEN_TAR_FILE is also set
    if [ -n "$SHA_MAVEN_TAR_FILE" ]; then
        export SHA=$SHA_MAVEN_TAR_FILE
        echo "Will use the user-specified SHA passed in: $SHA"
    fi
fi

apt-get update
apt-get -y install wget curl lsof jq gnupg libapr1 openssl gcc automake make cmake libtool libapr1-dev libssl-dev 
        
MAJOR_VER=$(echo $MAVEN_VERSION | awk -F. '{print $1}')
export BASE_URL=https://apache.osuosl.org/maven/maven-${MAJOR_VER}/${MAVEN_VERSION}/binaries
mkdir -p /usr/share/maven /usr/share/maven/ref
curl -fsSL -o /tmp/apache-maven.tar.gz ${BASE_URL}/apache-maven-${MAVEN_VERSION}-bin.tar.gz        
if [ -n "$SHA" ]; then
    echo "Verifying checksum of /tmp/apache-maven.tar.gz"
    echo "${SHA}  /tmp/apache-maven.tar.gz" | sha512sum -c
fi

tar -xzf /tmp/apache-maven.tar.gz -C /usr/share/maven --strip-components=1
rm -f /tmp/apache-maven.tar.gz
ln -s /usr/share/maven/bin/mvn /usr/bin/mvn

apt-get install -y apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
add-apt-repository -y ppa:git-core/ppa
apt-get update
apt-cache policy docker-ce
apt-get install -y docker-ce-cli git
git config --global --add safe.directory $GITHUB_WORKSPACE
wget https://github.com/cli/cli/releases/download/v2.14.7/gh_2.14.7_linux_amd64.deb
apt install ./gh_2.14.7_linux_amd64.deb

```
7*. 
Sample `sonar-project.properties` config file for SonarQube scanning:
```yaml
sonar.projectKey=subscription-management
sonar.projectName=subscription-management
sonar.issuesReport.html.enable=true
sonar.sources=.
sonar.java.binaries=./src/**,./target/**
sonar.c.file.suffixes=-
sonar.cpp.file.suffixes=-
sonar.objc.file.suffixes=-
sonar.coverage.exclusions=2.0.56.Final/**/*.java,**/*Test.java,tests/**,src/test/**,tools/**,deploy/**
sonar.exclusions=2.0.56.Final/**
```
8*. 
```yaml
      - name: Push to JFrog
        if: github.event_name == 'push' && github.ref_name == github.event.repository.default_branch
        shell: bash
        run: |
          if [ "$SKIP_JFROG_PUSH" == "true" ]; then
              echo "skipping; SKIP_JFROG_PUSH is set to 'true'"
              exit 0
          fi
          version=${{ steps.tag_version.outputs.tag }}
          export BRANCH_VERSION=${version}
          mvn -B -X versions:set -DnewVersion=${BRANCH_VERSION}.${GITHUB_RUN_NUMBER}
          mvn -s settings.xml -B deploy -DskipTests -Dcheckstyle.skip -Dskip.it=true -Dsonar.skip
```
9*.
```yaml
      - name: OWASP Dependency-Check
        if: github.event_name == 'push' && github.ref_name == github.event.repository.default_branch
        continue-on-error: true
        run: |
          mvn -s settings.xml dependency-check:aggregate -DskipTests -Dcheckstyle.skip -Dskip.it=true -Dsonar.skip
```
10*.
```yaml
      - name: Upload Dependency-Check report
        if: github.event_name == 'push' && github.ref_name == github.event.repository.default_branch
        uses: actions/upload-artifact@v3
        with:
          name: dependency-check-report
          path: target/dependency-check-report.html
```
### Inputs/Secrets for mci-maven
| _Input_                | _Default_                                                | _Description_                                         | _Required_ |
|:-----------------------|:---------------------------------------------------------|:------------------------------------------------------|:-----------|
| username/quay_username | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                         | true       |
| password/quay_password | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                         | true       |
| sonar_token            | ```${{ secrets.SONARQUBE_PROJECT_TOKEN }}```             | SonarQube token                                       | true       |
| jfrog_user             | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                        | true       |
| jfrog_passwd           | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                        | true       |
| APP_NAME               | ```${{ env.APP_NAME }}```                                | Application Name, Usually same as the repository name | true       |

# build:
build depends on unit-test job is executed during all 3 triggers based on the conditions. All four jobs calls 4 different workflows to perform their respective build operations.  The workflow that is used for the execution of lint ![mci-build.yaml](.github/workflows/mci-build.yaml). For java based application the **mci-maven** job is triggered. 

## 1. mci-maven
Building or packaging of the artifacts for java based applications using maven build tool in GLCP are done using the workflow ![mci-build-maven.yaml](.github/workflows/mci-build-maven.yaml). The workflow is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'maven'**]. The Jobs executed in mci-build-maven.yaml are **build-maven, coreupdate**.

### a. create-tag
The following stpes are executed in order.

  |   | _description_                           | _actions_                                   |
  |:-:|:----------------------------------------|:--------------------------------------------| 
  | 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```               | 
  | 2 | set-environment variables for the job   | ```glcp/mci-actions-variables-restore@v2``` | 
  | 3 | Set environment variable VERSION_NUMBER | ```glcp/mci-actions-version-number@v1```    | 
  | 4 | Assemble Git Tag                        | ```glcp/mci-actions-version-tag/java@```    |


### b. build-app
  The build-app job is used for the app build.

  The following steps are executed in order.

|   | _Description_                                                   | _Actions_                                     | _Executions_                         |
|:-:|:----------------------------------------------------------------|:----------------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job | ```glcp/mci-actions-workspace-restore@v1```   | The step is executed on all triggers |
| 2 | Set environment variables for the job.                          | ```glcp/mci-actions-variables-restore@v2```   | The step is executed on all triggers |
| 3 | Docker App Build                                                | ```glcp/mci-actions-build/docker-build@@v1``` | The step is executed on all triggers |

#### Inputs/Secrets for build-app

| _Input_        | _Default_                                         | _Description_                                                       | _Required_ |
|:---------------|:--------------------------------------------------|:--------------------------------------------------------------------|:-----------|
| appname        | ```${{ env.APP_NAME }}```                         | Application name in coreupdate, Usually same as the repository name | true       |
| tag            | ```${{ needs.create-tag.outputs.tag }}```         | GitHub tag                                                          | true       |
| build_type     | ```app```                                         | Indicates that app build should be performed                        | true       |
| registry       | ```quay.io```                                     | Registry name                                                       | true       |
| image_registry | ```quay.io/ccsportal/${{ env.APP_NAME }}```       | Quay Registry                                                       | true       |
| target         | ```${{ needs.set-vals.outputs.docker_target }}``` | Docker target                                                       | true       |
| docker_push    | ```${{ needs.set-vals.outputs.docker_push }}```   | Whether to push Docker image or not                                 | true       |
| secrets        | ```${{ toJson(secrets) }}```                      | object containing the secrets                                       | true       |


### c. build-automation
The build-automation job is used for the automation build.

The following steps are executed in order.

|   | _Description_                          | _Actions_                                     | _Executions_                         |
|:-:|:---------------------------------------|:----------------------------------------------|:-------------------------------------|
| 1 | Clone the repository                   | ```actions/checkout@v3.3.0```                 | The step is executed on all triggers |
| 2 | Set environment variables for the job. | ```glcp/mci-actions-variables-restore@v2```   | The step is executed on all triggers |
| 3 | Check for Dockerfile_FT existence      | ```andstor/file-existence-action@v2```        | The step is executed on all triggers |
| 4 | Docker Automation Build                | ```glcp/mci-actions-build/docker-build@@v1``` | The step is executed on all triggers |

#### Inputs/Secrets for build-automation

| _Input_        | _Default_                                         | _Description_                                                       | _Required_ |
|:---------------|:--------------------------------------------------|:--------------------------------------------------------------------|:-----------|
| appname        | ```${{ env.APP_NAME }}```                         | Application name in coreupdate, Usually same as the repository name | true       |
| tag            | ```${{ needs.create-tag.outputs.tag }}```         | GitHub tag                                                          | true       |
| build_type     | ```automation```                                  | Indicates that automation build should be performed                 | true       |
| registry       | ```quay.io```                                     | Registry name                                                       | true       |
| image_registry | ```quay.io/ccsportal/${{ env.APP_NAME }}```       | Quay Registry                                                       | true       |
| target         | ```${{ needs.set-vals.outputs.docker_target }}``` | Docker target                                                       | true       |
| docker_push    | ```${{ needs.set-vals.outputs.docker_push }}```   | Whether to push Docker image or not                                 | true       |
| secrets        | ```${{ toJson(secrets) }}```                      | object containing the secrets                                       | true       |


### c. coreupdate
  The coreupdate job is used to update the channel versions in Coreupdate. The core update will be executed when PUBLISH_DOCKER_IMAGE is true.

The following stpes are executed in order.

  |   | _Description_                          | _Actions_                                                      | _Executions_                         |
  |:-:|:---------------------------------------|:---------------------------------------------------------------|:-------------------------------------|
  | 1 | Clone the repository                   | ```actions/checkout@v3.3.0```                                  | The step is executed on all triggers |
  | 2 | Set environment variables for the job. | ```glcp/mci-actions-variables-restore@v2```                    | The step is executed on all triggers |
  | 3 | Check for Dockerfile_FT existence      | ```andstor/file-existence-action@v2```                         | The step is executed on all triggers |
  | 4 | Channel                                | set coreupdate channel is set as output using bash logic below | The step is executed on all triggers |
  | 5 | Coreupdate Push                        | ```glcp/ccs-automation/ci_cd_commons/coreupdate@v3```          | The step is executed on all triggers |

4*. Determining the channel for core update
```yaml
      - name: Channel
        id: channel
        shell: bash
        run: |
          CHANNEL=""
          if [[ "${{ github.event_name }}" == "workflow_dispatch" ]]; then CHANNEL="${{env.CHANNEL}}"; fi
          if [[ "${{ github.event_name }}" == "push" && "${{ github.ref_name }}" == "${{ github.event.repository.default_branch }}" ]]; then CHANNEL="Jenkins-Continuous"; fi
          if [[ "${{ github.event.action }}" == "released" ]]; then CHANNEL="Jenkins-Continuous"; fi
          if [[ ${{ startsWith(github.ref, 'refs/heads/master') }} == true ]]; then CHANNEL="${{env.CHANNEL}}"; fi
          echo "channel=$CHANNEL" >> $GITHUB_OUTPUT
          echo "Channel: $CHANNEL"

```

#### Inputs/Secrets for coreupdate

| _Input_           | _Default_                                                | _Description_                                                       | _Required_ |
|:------------------|:---------------------------------------------------------|:--------------------------------------------------------------------|:-----------|
| APP_NAME          | ```${{ env.APP_NAME }}```                                | Application name in coreupdate, Usually same as the repository name | true       |
| APP_ID            | ```${{ env.APP_ID }}```                                  | Coreupdate Application ID                                           | true       |
| quay_username     | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                                       | true       |
| quay_password     | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                                       | true       |
| jfrog_username    | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                                      | true       |
| jfrog_password    | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                                      | true       |
| UPDATECTL_USER    | ```${{ secrets.CCS_UPDATECTL_USER }}```                  | updatectl user                                                      | true       |
| UPDATECTL_SERVER  | ```${{ secrets.CCS_UPDATECTL_SERVER }}```                | updatectl server                                                    | true       |
| UPDATECTL_KEY     | ```${{ secrets.CCS_UPDATECTL_KEY }}```                   | updatectl password                                                  | true       |
| COREROLLER_USER   | ```${{ secrets.CCS_COREROLLER_USER }}```                 | coreroller user                                                     | true       |
| COREROLLER_SERVER | ```${{ secrets.CCS_COREROLLER_SERVER }}```               | coreroller server                                                   | true       |
| COREROLLER_KEY    | ```${{ secrets.CCS_COREROLLER_KEY }}```                  | coreroller password                                                 | true       |
| gh_token          | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                                                        | true       |

# post-build:
post-build depends on build job and is executed during all 3 triggers. The workflow that is used for the execution of post-build ![mci-post-build.yaml](.github/workflows/mci-post-build.yaml). For java based application the **sonar-maven, set-matrix-variables, sbom-upload** jobs are triggered. 

## 1. set-matrix-variables
The job is used to setup matrix output for sbom-upload matrix strategy.

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                     | _Actions_                                     | _Execution_                          |
|:-:|:------------------------------------------------------------------|:----------------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job   | ```actions/download-artifact@v3```            | The step is executed on all triggers |
| 2 | set-environment variables for the job.                            | ```actions-tools/yaml-outputs@v2```           | The step is executed on all triggers |
| 3 | set-matrix JSON output                                            | Executed using bash commands ```3*```         | The step is executed on all triggers |

  3*. set matrix JSON output
```yaml
  - id: set-matrix
    run: echo "::set-output name=matrix::{\"include\":[{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL1 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME1 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL2 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME2 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL3 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME3 }}\"}]}"

```
## 3. sbom-upload
Sbom generation is done after build steps are done as a post build step only for the default branch.
To enable sbom generation the inputs like product-name , product-version and dist-list are taken from https://github.com/glcp/managed-ci-workflow/blob/main/utils/vtn-config.yaml.
```yaml
Generic:
  - name: 'properties'
    org-name: 'GreenLake'
    api-url: 'https://vtn.hpecorp.net/api'
 
Projects:
  - name: 'platform-analytics-ingest-etl'
    product-name: 'platform-analytics-ingest-etl'
    product-version: '1.0.0'
    dist-list: 'giotto-devops'
``` 
Sbom generation and upload to VTN is done from the runner label `managed-ci-vtn`. The 
action it uses is `glcp/mci-actions-sbom-upload@v1` which internally 
uses `hpe-actions/cosign@v3` action for signing and few vtn api calls to upload the sbom 
to VTN.
The job performs the cosign, verify and uploading sbom to VTN. The job is executed only 
on default_branch

**The following steps are executed when conditions are satisfied**.

|   | _Description_                                                   | _Actions_                                                      | _Execution_                                 |
|:-:|:----------------------------------------------------------------|:---------------------------------------------------------------|:--------------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job | ```actions/download-artifact@v3```                             | The step is executed on only default branch |
| 2 | set-environment variables for the job.                          | ```actions-tools/yaml-outputs@v2```                            | The step is executed on only default branch |
| 3 | Docker Login to jfrog artifactory                               | ```docker/login-action@v2```                                   | The step is executed on only default branch |
| 4 | Docker Login to quay                                            | ```docker/login-action@v2```                                   | The step is executed on only default branch |
| 5 | Cosign verify and upload sbom                                   | ```glcp/managed-ci-workflow/actions/upload-sbom@sbom_upload``` | The step is executed on only default branch |
 

# 3. For scala based application using sbt build tool in GLCP
# Triggers:
  The Workflow has 3 Triggers which are **workflow_dispatch** to enable developers to execute the workflow in feature branches, **pull_request** to enable the workflow to get triggered when a PR is opened, **push** to enable the workflow to trigger on merge to deafult_branch or when a release tag is created.

| _Trigger_             | _Description_                                                                                             |
|:----------------------|:----------------------------------------------------------------------------------------------------------|
| **workflow_dispatch** | To enable the teams make use of the Managed CI workflow in feature/non-default branches for manual CI     |
| **pull_request**      | To trigger the Managed CI workflow when a PR is opened, updated.                                          |
| **push**              | [branch: main, master, mainline]: To Trigger the Managed CI workfow when PR is merged to default branch.<br>[tags: [0-9]+.[0-9]+.[0-9]+]: To Trigger the Managed CI workfow when a tag is created for the release |

# pre-check:
  The validation of the CI is done on pre-check. The workflow used for the execution of pre-check is ![mci-pre-check.yaml](.github/workflows/mci-pre-check.yaml). For Scala based application the **secret-scanner, mci-sbt** jobs are triggered.

**The jobs that are executed for java based application using maven build tool on pre-check**
| _Jobs_             | _Description_                                                                  |
|--------------------|--------------------------------------------------------------------------------|
| **secret-scanner** | Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner.|
| **mci-sbt**        | mci-sbt job is intended for application based on **scala**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'sbt'**].|

## 1. secret-scanner:
  Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner.
  The workflow used for the execution of secret-scanner is ![scanning-workflow.yml](https://github.com/glcp/Secret-Scan-Tool/blob/main/.github/workflows/scanning-workflow.yml)

### Deafult Inputs for secret-scan
| _Input_             | _Default_                               | _Description_                                                       | _Required_  |
|:-------------------:|:----------------------------------------|:--------------------------------------------------------------------|:------------|
| repo                | ```${{github.event.repository.name}}``` | Name of the repository where secret scan need to be executed        | true        |
| branch              | ```${{github.ref_name}}```              | Branch in which secret-scan need to be executed on the given repo   | true        |

## 2. mci-sbt:
The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'sbt'**]. 

  **when the conditions are satisfied the job does the following actions in order.**

  |   | _description_                          | _actions_                                                                     | _execution_                          |
  |:-:|:---------------------------------------|:------------------------------------------------------------------------------|:-------------------------------------|
  | 1 | Clone the Repository                   |  ```actions/checkout@v3.3.0```                                                | The step is executed on all triggers |
  | 2 | zip and upload artifacts with names workspace and workspace-clean-artifacts to use them in future jobs | ```actions/upload-artifact@v3``` | The step is executed on all triggers |

# pre-stage:
The pre-stage job depends on the pre-check job. The pre-stage workflow need/will be in the application repository **.github/workflows** folder. This is just a boilerplate workflow, which the application team can use to execute project specific jobs before Lint that cann't be incorporated in MANAGED CI. The reference workflow for pre-stage is ![mci-pre-stage.yaml](templates/mci-pre-stage.yaml)

# lint:
Lint job depends on pre-stage job and is executed only on PR. The workflow that is used for the execution of lint ![mci-lint.yaml](.github/workflows/mci-lint.yaml). For scala based application the **mci-sbt** job is triggered.

## 1. mci-sbt:
mci-sbt job is intended for applications based on **scala**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'sbt' && github.ref != format('refs/heads/{0}', github.event.repository.default_branch)**].

  **when the conditions are satisfied the job does the following actions.**
  |    | _description_                                                    | _actions_                                                 | _Execution_                           |
  |:--:|:-----------------------------------------------------------------|:----------------------------------------------------------|:--------------------------------------|
  | 1  | Download and unzip workspace artifacts uploaded in previous job  | ```actions/download-artifact@v3```                        | Executed if the branch is non-default |
  | 2  | set-environment variables for the job.                           | ```actions-tools/yaml-outputs@v2```                       | Executed if the branch is non-default |
  | 3  | Set up JDK                                                       | ```actions/setup-java@v1```                               | Executed if the branch is non-default |
  | 4  | Setup environmental credentials                                  | ```glcp/harmony-actions-artifactory-credentials@master``` | Executed if the branch is non-default |
  | 5  | Copy credentials to required location                            | Executed using bash commands as given in ```5*```         | Executed if the branch is non-default |
  | 6  |Linting for SCALA using scalaFmt                                  | Executed using sbt commands as given in ```6*```          | Executed if the branch is non-default |
  | 7  | zip and upload artifacts with names workspace to use them in future jobs | ```actions/upload-artifact@v3```                  | Executed if the branch is non-default |

  5*. Copy credentials to required location using
```yaml
  - name: Copy Credentials to right location
    run: |
      echo $HOME
      set -e -x
      mkdir -p $HOME/.ivy2/
      cp "/home/runner/work/_temp/_github_home/.ivy2/.credentials-hpeartifacts.jfrog.io" \
        "$HOME/.ivy2/.credentials-hpeartifacts.jfrog.io"
      mkdir -p $HOME/.pip/
      cp "/home/runner/work/_temp/_github_home/.pip/pip.conf" \
        "$HOME/.pip/pip.conf"
      cp "/home/runner/work/_temp/_github_home/.pypirc" \
        "$HOME/.pypirc" 
    shell: bash
```
  6*. Linting using scalaFmt
```yaml
  - name: scalaFmt
    id: scalaFmt
    env:
      GITHUB_TOKEN: ${{ env.GITHUB_TOKEN }}
      GIT_AUTHOR_NAME: Scala FMT
      GIT_AUTHOR_EMAIL: glcp-gh-bot@github.com
      GIT_COMMITTER_NAME: Scala FMT
      GIT_COMMITTER_EMAIL: glcp-gh-bot@github.com
    run: |
      sbt ";scalafmtAll;scalafmtSbt"
      echo "reformatting code using scalafmt"
      git remote set-url origin "https://x-access-token:$GITHUB_TOKEN@github.com/${{ github.repository }}.git"
      git add .
      git commit -m "Reformat code using ScalaFmt" --no-verify || echo -e "notCommit: true" >> .github/mci-variables.yaml
      git push -u origin ${{ github.ref }} --no-verify
    shell: bash
```
#### Inputs/Secrets for mci-sbt

| _Input_           | _Default_                                         | _Description_                       | _Required_  |
|:------------------|:--------------------------------------------------|:------------------------------------|:------------|
| java-version      | ```${{ env.JAVA_VERSION }}```                     | JAVA version to be used for Linting | true        |
| ARTIFACTORY_USER  | ```${{ secrets.HPE_ARTIFACTORY_BBOB_USERNAME }}```| Artifactory Username                | true        |
| ARTIFACTORY_PWD   | ```${{ secrets.HPE_ARTIFACTORY_BBOB_ACCESS_TOKEN }}``` | Artifactory Password                | true        |

# pre-test:
The pre-test job depends on the lint job. The pre-test workflow need/will be in the repository **.github/workflows** folder. This is just a boilerplate workflow, which is the application team can use to execute project specific jobs before unit-test that cann't be incorporated in MANAGED CI. The reference workflow for pre-test is ![mci-pre-test.yaml](templates/mci-pre-test.yaml)

# unit-test:
The unit-test depends on pre-test job and is executed during all 3 triggers. The workflow that is used for the execution of unit-test ![mci-unit-test.yaml](.github/workflows/mci-unit-test.yaml). For scala based application the **mci-sbt** job is triggered.

## 1. mci-sbt:
  mci-sbt job is intended for application based on **scala**. The job is executed on only non-default branches and based on the conditions provided in **Repository Variables** [**github.ref != format('refs/heads/{0}', github.event.repository.default_branch) &&  vars.GLCP_BUILD_SYSTEM == 'sbt'**.

  **when the conditions are satisfied the job does the following actions.**
  |    | _description_                                                        | _actions_                                                 | _Execution_                           |
  |:--:|:---------------------------------------------------------------------|:----------------------------------------------------------|:--------------------------------------|
  | 1  | Download and unzip workspace artifacts uploaded in previous job      | ```actions/download-artifact@v3```                        | Executed if the branch is non-default |
  | 2  | set-environment variables for the job.                               | ```actions-tools/yaml-outputs@v2```                       | Executed if the branch is non-default |
  | 3  | Set up JDK                                                           | ```actions/setup-java@v1```                               | Executed if the branch is non-default |
  | 4  | Setup environmental credentials                                      | ```glcp/harmony-actions-artifactory-credentials@master``` | Executed if the branch is non-default |
  | 5* | Copy credentials to required location                                | Step Executed using bash commands as given in ```5*```    | Executed if the branch is non-default |
  | 6  | Login to Harmony Docker                                              | ```docker/login-action@v2```                              | Executed if the branch is non-default |
  | 7  | Prod Internal Docker                                                 | ```docker/login-action@v2```                              | Executed if the branch is non-default |
  | 8* | Verify for sbt                                                       | Step Executed using sbt commands as given in ```6*```     | Executed if the branch is non-default |
  | 9  | zip and upload artifacts with names workspace to use them in future jobs | ```actions/upload-artifact@v3```                      | Executed if the branch is non-default |

  5* Copy credentials to required location using
```yaml
  - name: Copy Credentials to right location
    run: |
      echo $HOME
      set -e -x
      mkdir -p $HOME/.ivy2/
      cp "/home/runner/work/_temp/_github_home/.ivy2/.credentials-hpeartifacts.jfrog.io" \
        "$HOME/.ivy2/.credentials-hpeartifacts.jfrog.io"
      mkdir -p $HOME/.pip/
      cp "/home/runner/work/_temp/_github_home/.pip/pip.conf" \
        "$HOME/.pip/pip.conf"
      cp "/home/runner/work/_temp/_github_home/.pypirc" \
        "$HOME/.pypirc" 
    shell: bash
```
  8* Running SBT verify based on the notCommit output generated in lint/harmony-sbt job
```yaml
    - name: sbt verify
      if: ${{ env.notCommit }}
      run: sbt verify
      shell: bash
```

#### Inputs/Secrets for mci-sbt

| _Input_           | _Default_                                          | _Description_                           | _Required_ |
|:------------------|:---------------------------------------------------|:----------------------------------------|:---------- |
| java-version      | ```${{ env.JAVA_VERSION }}```                      | JAVA version to be used for sbt verify  | true       |
| ARTIFACTORY_USER  | ```${{ secrets.HPE_ARTIFACTORY_BBOB_USERNAME }}``` | Artifactory Username                    | true       |
| ARTIFACTORY_PWD   | ```${{ secrets.HPE_ARTIFACTORY_BBOB_ACCESS_TOKEN }}```  | Artifactory Password                    | true       |


# build:
build depends on unit-test job and is executed during all 3 triggers based on the conditions.  The workflow that is used for the execution of lint ![mci-build.yaml](.github/workflows/mci-build.yaml). For Scala based application the **mci-sbt** job is triggered. 

## 1. mci-sbt
  Building or packaging of the artifacts for scala based applications using sbt build tool in GLCP are done using the workflow ![mci-build-sbt.yaml](.github/workflows/mci-build-sbt.yaml). The workflow is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'sbt'**]. The Jobs executed in mci-build-sbt.yaml are **build-sbt**.

### a. build-sbt
  The build-sbt job is executed only when the triggered branch is default branch or else it will be skipped.

  **when the conditions are satisfied the job does the following actions.**
  |    | _description_                                                        | _actions_                                                 |
  |:--:|:---------------------------------------------------------------------|:----------------------------------------------------------|
  | 1  | Download and unzip workspace artifacts uploaded in previous job      | ```actions/download-artifact@v3```                        | 
  | 2  | set-environment variables for the job.                               | ```actions-tools/yaml-outputs@v2```                       | 
  | 3  | Set up JDK                                                           | ```actions/setup-java@v1```                               | 
  | 4  | Setup environmental credentials                                      | ```glcp/harmony-actions-artifactory-credentials@master``` | 
  | 5* | Copy credentials to required location                                | Step Executed using bash commands as given in ```5*```    | 
  | 6  | Login to Harmony Docker                                              | ```docker/login-action@v2```                              | 
  | 7  | Prod Internal Docker                                                 | ```docker/login-action@v2```                              | 
  | 8  | setup helm                                                           | Using helm commands as shown in ```8*```                  | 
  | 9  | Build and Publish Artifact                                           | Using sbt commands as shown in ```9*```                   |
  | 10 | Set ARTIFACT_URLS with sha1s                                         | artifacts.json file is parsed and key:value pairs are added to .github/mci-variables.yaml |
  | 11 | Write version to a file                                              | Using sbt commands as shown in ```11*```                  |
  | 12 | Clone harmony versions repository                                    | ```actions/checkout@v3.3.0```                             |
  | 13 | Update harmony-versions                                              | Using bash commands as shown in ```13*```                 |
  | 14 | commit the if any updates done on harmony-version.yaml               | Using bash commands as shown in ```14*```                 |


5*. Copy Credentials to required loaction using
```yaml
      - name: Copy Credentials to right location
        shell: bash
        run: |
          set -e -x
          mkdir -p $HOME/.ivy2/
          cp "/home/runner/work/_temp/_github_home/.ivy2/.credentials-hpeartifacts.jfrog.io" \
            "$HOME/.ivy2/.credentials-hpeartifacts.jfrog.io"
          mkdir -p $HOME/.pip/
          cp "/home/runner/work/_temp/_github_home/.pip/pip.conf" \
            "$HOME/.pip/pip.conf"
          cp "/home/runner/work/_temp/_github_home/.pypirc" \
            "$HOME/.pypirc"
```

8*. Setup Helm using
```yaml
      - name: Setup helm
        shell: bash
        run: |
          helm plugin install https://github.com/belitre/helm-push-artifactory-plugin --version 1.0.2
          helm repo add helm-harmony-ops-local https://hpeartifacts.jfrog.io/hpeartifacts/helm-harmony-ops-local \
            --force-update --username ${{ env.ARTIFACTORY_USER }} --password ${{ env.ARTIFACTORY_PWD }}
          helm repo update
```
9*. Build and Publish sbt artifacts using
```yaml
      - name: Build and Publish Artifact
        if: ${{ github.ref != format('refs/heads/{0}', github.event.repository.default_branch) }}
        env:
          HPE_ARTIFACTORY_USERNAME: ${{ env.ARTIFACTORY_USER }}
          HPE_ARTIFACTORY_PASSWORD: ${{ env.ARTIFACTORY_PWD }}
        run: sbt build
        shell: bash
```
11*.  Writing version to a file
```yaml         
      - name: Write version to file
        shell: bash
        run: |
          set -e -x
          sbt version > target/version.txt
```
13*. updating Harmony veriosn using teh version file 
```yaml            
      - name: Update harmony-versions
        shell: bash
        run: |
          export REPOSITORY=${{ github.repository }}
          cat > exec.py <<- EOM
          import json, os, sys, yaml, re
          manifest_path="harmony-versions/manifests/harmony-version.yaml"
          version_path="target/version.txt"
          # Generate pyspark version from actual version. Equaivalent to https://github.com/glcp/harmony-core/blob/master/pyspark_base/build.sbt#L8-L38
          def pyspark_version(version):
            version = version.replace("-", ".").split(".")
            if len(version) == 3:
              return version[0] + "." + version[1] + "." + version[2]
            elif len(version) <= 5:
              return version[0] + "." + version[1] + "." + version[2] + ".dev"
            else:
              tail = version[4:len(version)-1]
              dirty = 1 if len(tail) > 1 else 0
              commit = tail[0]
              return version[0] + "." + version[1] + "." + version[2] + ".dev" + str(int(commit, 16)) + str(dirty)
          with open(version_path, 'r', encoding='utf-8', errors='replace') as v:
              regex = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
              artifact_version = regex.sub('', v.read().split()[-2])
          with open(manifest_path) as m:
              artifact_repo = os.environ['REPOSITORY']
              manifest = yaml.load(m, Loader=yaml.Loader)
              for a in manifest:
                  if a == 'helm-hdu' or a == 'helm-ingest':
                      for b in manifest[a]:
                          manifest_repo = manifest[a][b]["git-repo"]
                          if artifact_repo in manifest_repo:
                              manifest[a][b]["tag"] = str(artifact_version)
                  else:
                      manifest_repo = manifest[a]["repo"]
                      if artifact_repo in manifest_repo:
                          if a == 'harmony-pyspark':
                            artifact_version = pyspark_version(artifact_version)
                          manifest[a]["tag"] = str(artifact_version)
          with open(manifest_path, 'w') as m:
              yaml.dump(manifest, m)
          EOM
          python exec.py
```
14*. Commiting the updates ack to the repository
```yaml          
      - name: commit
        shell: bash
        id: commit_step
        env:
          GITHUB_TOKEN: ${{ env.GITHUB_TOKEN }}
          GIT_AUTHOR_NAME: ghe-action
          GIT_AUTHOR_EMAIL: glcp-gh-bot@github.com
          GIT_COMMITTER_NAME: ghe-action
          GIT_COMMITTER_EMAIL: glcp-gh-bot@github.com
        run: |
          cd harmony-versions
          git add manifests/harmony-version.yaml
          git commit -m "Update versions (${{ github.repository }})" --no-verify || echo "Nothing to commit"
          if [[ ${{ github.ref }} == 'refs/heads/master' ]]
          then
            git push --no-verify || echo "Nothing to push"
          fi
```

# post-build:
post-build depends on build job and is executed during all 3 triggers. The workflow that is used for the execution of post-build ![mci-post-build.yaml](.github/workflows/mci-post-build.yaml). For scala based application the **sonar-sbt, set-matrix-variables, sbom-upload** jobs are triggered. 

## 1. sonar-maven 
The sonar-maven job is triggered on all trigger events. It performs the code quality analysis and check the quality gate status. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'sbt'**] 

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                   | _Actions_                             | _Execution_                          |
|:-:|:----------------------------------------------------------------|:--------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job | ```actions/download-artifact@v3```    | The step is executed on all triggers |
| 2 | set-environment variables for the job.                          | ```actions-tools/yaml-outputs@v2```   | The step is executed on all triggers |
| 3 | Override SBT Coverage Source Path for Sonar                     | Executed using bash commands ```3*``` | The step is executed on all triggers |
| 4 | Sonar Scan on the repository                                    | ```hpe-actions/sonarqube-scan@main``` | The step is executed on all triggers |

3*. 
```yaml
  - name: Override Coverage Source Path for Sonar
    shell: bash
    run: |
      pwd
      find . -name "scoverage.xml" -type f
      find . -name "scoverage.xml" -type f -exec sed -i'' -e "s/\/home\/runner\/work\/${{ github.event.repository.name }}\/${{ github.event.repository.name }}/\/github\/workspace/g" '{}' \;
```
## 2. set-matrix-variables 
The job is used to seup matrix output for sbom-upload matrix startegy.

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                   | _Actions_                             | _Execution_                          |
|:-:|:----------------------------------------------------------------|:--------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job | ```actions/download-artifact@v3```    | The step is executed on all triggers |
| 2 | set-environment variables for the job.                          | ```actions-tools/yaml-outputs@v2```   | The step is executed on all triggers |
| 3 | ste-matrix JSON output                                          | Executed using bash commands ```3*``` | The step is executed on all triggers |

  3*. set matrix JSON output
```yaml
  - id: set-matrix
    run: echo "::set-output name=matrix::{\"include\":[{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL1 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME1 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL2 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME2 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL3 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME3 }}\"}]}"

```
## 3. sbom-upload
Sbom generation is done after build steps are done as a post build step only for the default branch.
To enable sbom generation the inputs like product-name , product-version and dist-list are taken from https://github.com/glcp/managed-ci-workflow/tree/sbom_upload/utils/vtn-config.yaml.
```yaml
Generic:
  - name: 'properties'
    org-name: 'GreenLake'
    api-url: 'https://vtn.hpecorp.net/api'
 
Projects:
  - name: 'platform-analytics-ingest-etl'
    product-name: 'platform-analytics-ingest-etl'
    product-version: '1.0.0'
    dist-list: 'giotto-devops'
``` 
Sbom generation and upload to VTN is done from the runner label "managed-ci-vtn". The action it uses is glcp/managed-ci-workflow/actions/upload-sbom@2.0.0 which internally uses "hpe-actions/cosign@v3" action for signing and few vtn api calls to upload the sbom to VTN.
The job performs the cosign, verify and uploding sbom to VTN. The job is executed only on default_branch

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                   | _Actions_                                     | _Execution_                                 |
|:-:|:----------------------------------------------------------------|:----------------------------------------------|:--------------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job | ```actions/download-artifact@v3```            | The step is executed on only default branch |
| 2 | set-environment variables for the job.                          | ```actions-tools/yaml-outputs@v2```           | The step is executed on only default branch |
| 3 | Docker Login to jfrog artifactory                               | ```docker/login-action@v2```                  | The step is executed on only default branch |
| 4 | Docker Login to quay                                            | ```docker/login-action@v2```                  | The step is executed on only default branch |
| 5 | Cosign verify and upload sbom                   | ```glcp/managed-ci-workflow/actions/upload-sbom@sbom_upload```| The step is executed on only default branch |


# 4. For GO based application in GLCP
# Triggers:
  The Workflow has 3 Triggers which are **workflow_dispatch** to enable developers to execute the workflow in feature branches, **pull_request** to enable the workflow to get triggered when a PR is opened, **push** to enable the workflow to trigger on merge to deafult_branch or when a release tag is created.

| _Trigger_             | _Description_                                                                                             |
|:----------------------|:----------------------------------------------------------------------------------------------------------|
| **workflow_dispatch** | To enable the teams make use of the Managed CI workflow in feature/non-default branches for manual CI     |
| **pull_request**      | To trigger the Managed CI workflow when a PR is opened, updated.                                          |
| **push**              | [branch: main, master, mainline]: To Trigger the Managed CI workfow when PR is merged to default branch.<br>[tags: [0-9]+.[0-9]+.[0-9]+]: To Trigger the Managed CI workfow when a tag is created for the release |

# pre-check:
  The validation of the CI is done on pre-check. The workflow used for the execution of pre-check is ![mci-pre-check.yaml](.github/workflows/mci-pre-check.yaml). For GO based application the **secret-scanner, mci-golang** jobs are triggered.

The jobs that are executed for python based application on pre-check
| _Jobs_             | _Description_                                                                  |
|--------------------|--------------------------------------------------------------------------------|
| **secret-scanner** | Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner. |
| **mci-golang**     | python job is intended for application based on **golang**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'golang'**].|

## 1. secret-scanner:
Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner.
The workflow used for the execution of secret-scanner is ![scanning-workflow.yml](https://github.com/glcp/Secret-Scan-Tool/blob/main/.github/workflows/scanning-workflow.yml)

### Deafult Inputs for secret-scan
| _Input_             | _Default_                               | _Description_                                                       | _Required_  |
|:-------------------:|:----------------------------------------|:--------------------------------------------------------------------|:------------|
| repo                | ```${{github.event.repository.name}}``` | Name of the repository where secret scan need to be executed        | true        |
| branch              | ```${{github.ref_name}}```              | Branch in which secret-scan need to be executed on the given repo   | true        |

## 2. mci-golang:
The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'golang'**]. 

**when the conditions are satisfied the job does the following actions.**
|   | _description_                                                                                  | _actions_                        | _execution_                          |
|:-:|:-----------------------------------------------------------------------------------------------|:---------------------------------|:-------------------------------------|
| 1 | Clone the Repository                                                                           | ```actions/checkout@v3.3.0```    | The step is executed on all triggers |
| 2 | zip and upload artifacts as workspace and workspace-clean-artifacts to use them in future jobs | ```actions/upload-artifact@v3``` | The step is executed on all triggers |

# pre-stage:
  The pre-stage job depends on the pre-check job. The pre-stage workflow need/will be in the application repository **.github/workflows** folder. This is just a boilerplate workflow, which the application team can use to execute project specific jobs before Lint that cann't be incorporated in MANAGED CI. The reference workflow for pre-stage is ![mci-pre-stage.yaml](templates/mci-pre-stage.yaml)

# lint:

The lint job depends on the pre-stage job and is configured to be executed only on PR.
The workflow that is used for the execution of lint is ![mci-lint.yaml](.github/workflows/mci-lint.yaml).
For Go-based applications, the **mci-golang** job is triggered.

## 1. mci-golang:
  mci-golang job is intended for applications based on **golang**. The job is 
  executed based on the conditions provided in **Repository Variables**:<br>
  **if: vars.GLCP_BUILD_SYSTEM == 'golang' && github.event_name == 'pull_request'**.
  
  **when the conditions are satisfied the job does the following actions.**

  |   | _Description_                                                                                                               | _Actions_                                                            | _Execution_              |
  |:-:|:----------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------|:-------------------------|
  | 1 | Download and unzip workspace artifacts uploaded in previous job                                                             | ```actions/download-artifact@v3```                                   | Executed on all triggers |
  | 2 | set-environment variables for the job.                                                                                      | ```actions-tools/yaml-outputs@v2```                                  | Executed on all triggers |
  | 3 | set-up GO                                                                                                                   | ```actions/setup-go@v2```                                            | Executed on all triggers |
  | 4 | Configure ![Ruleguard](https://github.com/glcp/managed-ci-actions/tree/main/ruleguard-golangci/) integration for Go linting | ```glcp/managed-ci-workflow/actions/setup-ruleguard-golangci@main``` | Executed on all triggers |
  | 5 | Linting for GO                                                                                                              | ```golangci/golangci-lint-action@v3```                               | Executed on all triggers |
  | 6 | zip and upload artifacts with names workspace to use them in future jobs                                                    | ```actions/upload-artifact@v3```                                     | Executed on all triggers |

#### Inputs/Secrets for mci-golang
| _Input_            | _Default_                   | _Description_                     | _Required_ |
|:-------------------|:----------------------------|:----------------------------------|:---------- |
| go-version         | ```${{ env.GO_VERSION }}``` | GO version to be used for Linting | true       |

# pre-test:
The pre-test job depends on the lint job. The pre-test workflow need/will be in the repository **.github/workflows** folder. This is just a boilerplate workflow, which is the application team can use to execute project specific jobs before unit-test that cann't be incorporated in MANAGED CI. The reference workflow for pre-test is ![mci-pre-test.yaml](templates/mci-pre-test.yaml)

# unit-test:
unit-test depends on pre-test job and is executed during all 3 triggers. The workflow that is used for the execution of unit-test ![mci-unit-test.yaml](.github/workflows/mci-unit-test.yaml). For GO based application the **mci-golang** job is triggered.

## 1. mci-golang:
  mci-golang job is intended for CCS application based on **golang**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'golang']**.

  **when the conditions are satisfied the job does the following actions.**

  |   | _Description_                                                     | _Actions_                                   | _Execution_              |
  |:-:|:------------------------------------------------------------------|:--------------------------------------------|:-------------------------|
  | 1 | Download and unzip workspace artifacts uploaded in previous job   | ```actions/download-artifact@v3```          | Executed on all triggers |
  | 2 | set-environment variables for the job.                            | ```actions-tools/yaml-outputs@v2```         | Executed on all triggers |
  | 3 | set-up GO                                                         | ```actions/setup-go@v2```                   | Executed on all triggers |
  | 4 | Using cache to improve workflow execution time                    | ```actions/cache@v3```                      | Executed on all triggers |
  | 5 | Executing unit test                                               | Executing unit-test using Makefile ```5*``` | Executed on all triggers |
  | 6 | zip and upload artifacts with names workspace to use them in future jobs | ```actions/upload-artifact@v3```     | Executed on all triggers |

  5* Run unit-tests using Makefile. The application team or project team is responsible to setup Makefile to be used for unit tests.
```yaml
  - name: Run unit tests
    run: make test 
```

***Note: As of now the Feature Tests/Functional Tests are not incorporated as a part of workflows that are managed by DevOps team, The team need to configure the FTs in pre-test.yaml job using the workflow 
 .github/mci-pre-test.yaml which is maintained by the respective repository owner.

### Inputs/Secrets for mci-golang
| _Input_            | _Default_                    | _Description_                          | _Required_ |
|:-------------------|:-----------------------------|:---------------------------------------|:---------- |
| go-version         | ```${{ env.GO_VERSION }}```  | GO version to be used for unit testing | true       |

# build:
build depends on unit-test job and is executed during all 3 triggers based on the conditions. All four jobs calls 4 different workflows to perform their respective build operations. The workflow that is used for the execution of build ![mci-build.yaml](.github/workflows/mci-build.yaml). For python based application the **mci-golang** job is triggered.

## 1. mci-golang
Building or packaging of the artifacts for GO based applications in GLCP are done using the workflow ![mci-build-go.yaml](.github/workflows/mci-build-go.yaml). The workflow is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'go'**]. The Jobs executed in mci-build-maven.yaml are **create-tag, set-matrix-variables, build-app, build-automation, coreupdate**.

### a. create-tag
  The tag for the build is determinied and set as output using the create-tag job. the create-tag is executed on all trigger events.

The following steps are executed in order in create-tag job.
  |   | _description_                          | _actions_                                                           | 
  |:-:|:---------------------------------------|:--------------------------------------------------------------------|
  | 1 | Cloning the application repository     | ```actions/checkout@v3.3.0```                                       |
  | 2 | set-environment variables for the job. | ```actions-tools/yaml-outputs@v2```                                 | 
  | 3 | Create tag                             | Steps Executed using bash commands and actions as given in ```3*``` | 

3*. Creating tags based on the triggers
```yaml
    - name: Create a custom TAG
      if: (startsWith(github.ref, 'refs/tags/') || github.event_name == 'workflow_dispatch')
      id: custom_tag
      shell: bash
      run: |
        if [[ "${{ github.event_name }}" == "push" ]]; then
          export tag="${{ github.ref_name }}"
        else
          export tag="${{ env.VERSION }}.${{ github.run_number }}-dev"
        fi
        echo "Git Tag version: $tag"
        echo "CustomTag=$tag" >> $GITHUB_OUTPUT

    - name: Git Tag
      if: github.event_name == 'push' && startsWith(github.ref, 'refs/heads/')
      uses: glcp/mci-actions-tag-git@v1.0
      id: new_tag

    - name: Tag Check
      id: check_tag
      run: |
        if [[ ! -z "${{ steps.custom_tag.outputs.CustomTag }}"  ]]; then
          echo "CustomTag input is not empty"
          echo "tag=${{ steps.custom_tag.outputs.CustomTag }}" >> $GITHUB_ENV
        elif [[ ! -z "${{ steps.new_tag.outputs.gittag }}" ]]; then
          echo "gittag input is not empty"
          echo "tag=${{ steps.new_tag.outputs.gittag }}" >> $GITHUB_ENV
        else
          echo "NO TAG EXISTS"
        fi

        echo "${{ env.tag }}"

    - name: Tag Extensions
      id: build_tag
      run: |
        if [[ -z "${{ env.TAG_INPUT1 }}" ]]; then
          echo "input is empty"
          echo "tag1=${{ env.tag }}" >> $GITHUB_ENV
        else
          echo "input is not empty"
          echo "tag1=${{ env.tag }}-${{ env.TAG_INPUT1 }}" >> $GITHUB_ENV
        fi

        if [[ -z "${{ env.TAG_INPUT2 }}" ]]; then
          echo "input is empty"
          echo "tag2=${{ env.tag }}" >> $GITHUB_ENV
        else
          echo "input is not empty"
          echo "tag2=${{ env.tag }}-${{ env.TAG_INPUT2 }}" >> $GITHUB_ENV
        fi

        if [[ -z "${{ env.TAG_INPUT3 }}" ]]; then
          echo "input is empty"
          echo "tag3=${{ env.tag }}" >> $GITHUB_ENV
        else
          echo "input is not empty"
          echo "tag3=${{ env.tag }}-${{ env.TAG_INPUT3 }}" >> $GITHUB_ENV
        fi

        if [[ -z "${{ env.TAG_INPUT4 }}" ]]; then
          echo "input is empty"
          echo "tag4=${{ env.tag }}" >> $GITHUB_ENV
        else
          echo "input is not empty"
          echo "tag4=${{ env.tag }}-${{ env.TAG_INPUT4 }}" >> $GITHUB_ENV
        fi
```

### b. set-matrix-variables
  Creating json object output for the matrix strategy that is used build-app.
```yaml
      - name: Clone app repo
        uses: actions/checkout@v3.3.0
        with:
          persist-credentials: false
          fetch-depth: 0
          submodules: true

      - name: set-env/output variables
        continue-on-error: true
        uses: actions-tools/yaml-outputs@v2
        id: yaml
        with:
          file-path: '.github/mci-variables.yaml'

      - id: set-matrix
        run: |
          echo "matrix={\"include\":[{\"dockerfile_path\":\"${{ env.DOCKERFILE_PATH1 }}\",\"image_registry\":\"${{ env.IMAGE_REGISTRY1 }}\",\"target\":\"${{ env.TARGET1 }}\",\"tag\":\"${{ needs.create-tag.outputs.tag1 }}\"},{\"dockerfile_path\":\"${{ env.DOCKERFILE_PATH2 }}\",\"image_registry\":\"${{ env.IMAGE_REGISTRY2 }}\",\"target\":\"${{ env.TARGET2 }}\",\"tag\":\"${{ needs.create-tag.outputs.tag2 }}\"},{\"dockerfile_path\":\"${{ env.DOCKERFILE_PATH3 }}\",\"image_registry\":\"${{ env.IMAGE_REGISTRY3 }}\",\"target\":\"${{ env.TARGET3 }}\",\"tag\":\"${{ needs.create-tag.outputs.tag3 }}\"},{\"dockerfile_path\":\"${{ env.DOCKERFILE_PATH4 }}\",\"image_registry\":\"${{ env.IMAGE_REGISTRY4 }}\",\"target\":\"${{ env.TARGET4 }}\",\"tag\":\"${{ needs.create-tag.outputs.tag4 }}\"}]}" >> $GITHUB_OUTPUT
```

### c. build-app
  The build-app job is used for the app build and will be triggered only on workflow dispatch or push. The build app uses matrix startegy to execute the Docker Build and Publish action 1-4 times baswed on the inputs provided.

The following stpes are executed in order.
  |   | _description_                          | _actions_                                                        |
  |:-:|:---------------------------------------|:-----------------------------------------------------------------|
  | 1 | Cloning the application repository     | ```actions/checkout@v3.3.0```                                    |
  | 2 | set-environment variables for the job. | ```actions-tools/yaml-outputs@v2```                              |
  | 3 | Login to the Artifactory               | ```docker/login-action@v1```                                     |
  | 4 | Docker build and publish               | ```glcp/mci-actions-docker-build-push-app@v1.0```                |

### Inputs/Secrets for build-app

| _Input_         | _Default_                                                 | _Description_                                                       | _Required_ |
|:----------------|:----------------------------------------------------------|:--------------------------------------------------------------------|:---------- |
| APP_NAME        | ```${{ env.APP_NAME }}```                                 | Application name in coreupdate, Usually same as the repository name | true       |
| APP_ID          | ```${{ env.APP_ID }}```                                   | Coreupdate Application ID                                           | true       |
| dockerfile_path | ```${{ matrix.dockerfile_path }}```                       | Obtained from matrix                                                | true       |
| image_registry  | ```${{ matrix.image_registry }}```                        | Obtained from matrix                                                | true       |
| tag             | ```${{ matrix.tag }}```                                   | Obtained from matrix                                                | true       |
| target          | ```${{ matrix.target }}```                                | Obtained from matrix                                                | true       |
| quay_username   | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```           | Quay Username                                                       | true       |
| quay_password   | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}```  | Quay Password                                                       | true       |
| jfrog_username  | ```${{ secrets.CCS_JFROG_USERNAME }}```                   | JFROG Username                                                      | true       |
| jfrog_password  | ```${{ secrets.CCS_JFROG_PASSWORD }}```                   | JFROG password                                                      | true       |
| gh_token        | ```${{ env.GITHUB_APP_TOKEN }}```                        | Github Token                                                        | true       |


## build-automation
The build-automation job is used for the automation build and will be triggered only on workflow dispatch or push. The teams can skip the automation build if not needed using ```SKIP_AUTOMATION_BUILD: true``` in mci-variables.yaml. If the team has automation build the Tag and the Image registry used are tag1 from create-tag and IMAGE_REGISTRY1 from mci-variables.yaml hence need to be configured accordingly. This job also creates an output for the execution of coreupdate job based on ${{ env.SKIP_COREUPDATE }}.

The following stpes are executed in order.
  |   | _description_                          | _actions_                                                |
  |:-:|:---------------------------------------|:---------------------------------------------------------|
  | 1 | Cloning the application repository     | ```actions/checkout@v3.3.0```                            |
  | 2 | set-environment variables for the job. | ```actions-tools/yaml-outputs@v2```                      |
  | 3 | Docker build                           | ```glcp/mci-actions-docker-build-push-automation@v1.0``` |

### Inputs/Secrets for build-automation 

| _Input_         | _Default_                                                | _Description_                                                       | _Required_ |
|:----------------|:---------------------------------------------------------|:--------------------------------------------------------------------|:---------- |
| APP_NAME        | ```${{ env.APP_NAME }}```                                | Application name in coreupdate, Usually same as the repository name | true       |
| APP_ID          | ```${{ env.APP_ID }}```                                  | Coreupdate Application ID                                           | true       |
| quay_username   | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                                       | true       |
| quay_password   | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                                       | true       |
| jfrog_username  | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                                      | true       |
| jfrog_password  | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                                      | true       |
| gh_token        | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                                                        | true       |

## coreupdate
  The coreupdate job is used to update the channel versions in Coreupdate. The core update job is executed only if output created in build-automation job is not true.

The following stpes are executed in order.
  |   | _description_                           | _actions_                                                           |
  |:-:|:----------------------------------------|:--------------------------------------------------------------------| 
  | 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```                                       | 
  | 2 | set-environment variables for the job.  | ```actions-tools/yaml-outputs@v2```                                 | 
  | 3 | set coreupdate channel                  | coreupdate channel is set as output using bash conditional ```3*``` | 
  | 4 | coreupdate push                         | ```glcp/mci-actions-coreupdate@v1.0```               |
  | 5 | coreupdate push with fips               | ```glcp/mci-actions-coreupdate@v1.0```               |

3*. Determinig the channel for core update
```yaml
    - name: Channel
      id: channel
      shell: bash
      run: |
        CHANNEL=""
        if [[ "${{ github.event_name }}" == "workflow_dispatch" ]]; then CHANNEL="${{env.CHANNEL}}"; fi
        if [[ "${{ github.event_name }}" == "push" && "${{ github.ref_name }}" == "${{ github.event.repository.default_branch }}" ]]; then CHANNEL="Jenkins-Continuous"; fi
        echo "channel=$CHANNEL" >> $GITHUB_OUTPUT
        echo "Channel: $CHANNEL"
```

### Inputs/Secrets for coreupdate

| _Input_            | _Default_                                                | _Description_                                                       | _Required_ |
|:-------------------|:---------------------------------------------------------|:--------------------------------------------------------------------|:---------- |
| APP_NAME           | ```${{ env.APP_NAME }}```                                | Application name in coreupdate, Usually same as the repository name | true       |
| APP_ID             | ```${{ env.APP_ID }}```                                  | Coreupdate Application ID                                           | true       |
| quay_username      | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```          | Quay Username                                                       | true       |
| quay_password      | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                                                       | true       |
| jfrog_username     | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                                                      | true       |
| jfrog_password     | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                                                      | true       |
| UPDATECTL_USER     | ```${{ secrets.CCS_UPDATECTL_USER }}```                  |  updatectl user                                                     | true       |
| UPDATECTL_SERVER   | ```${{ secrets.CCS_UPDATECTL_SERVER }}```                |  updatectl server                                                   | true       |
| UPDATECTL_KEY      | ```${{ secrets.CCS_UPDATECTL_KEY }}```                   |  updatectl password                                                 | true       |
| COREROLLER_USER    | ```${{ secrets.CCS_COREROLLER_USER }}```                 | coreroller user                                                     | true       |
| COREROLLER_SERVER  | ```${{ secrets.CCS_COREROLLER_SERVER }}```               | coreroller server                                                   | true       |
| COREROLLER_KEY     | ```${{ secrets.CCS_COREROLLER_KEY }}```                  | coreroller password                                                 | true       |
| gh_token           | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                                                        | true       |

# post-build:
post-build depends on build job and is executed during all 3 triggers. The workflow that is used for the execution of post-build ![mci-post-build.yaml](.github/workflows/mci-post-build.yaml). For GO based application the **sonar-golang, set-matrix-variables, sbom-upload** jobs are triggered. 

## 1. sonar-golang 
The sonar-golang job is triggered on all trigger events. It performs the code quality analysis and check the quality gate status. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'golang'**] 

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                     | _Actions_                             | _Execution_                          |
|:-:|:------------------------------------------------------------------|:--------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job   | ```actions/download-artifact@v3```    | The step is executed on all triggers |
| 2 | set-environment variables for the job.                            | ```actions-tools/yaml-outputs@v2```   | The step is executed on all triggers |
| 3 | Sonar Scan on the repository                                      | ```hpe-actions/sonarqube-scan@main``` | The step is executed on all triggers |

## 2. set-matrix-variables
The job is used to seup matrix output for sbom-upload matrix startegy.

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                     | _Actions_                             | _Execution_                          |
|:-:|:------------------------------------------------------------------|:--------------------------------------|:-------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job   | ```actions/download-artifact@v3```    | The step is executed on all triggers |
| 2 | set-environment variables for the job.                            | ```actions-tools/yaml-outputs@v2```   | The step is executed on all triggers |
| 3 | ste-matrix JSON output                                            | Executed using bash commands ```3*``` | The step is executed on all triggers |

3*. set matrix JSON output
```yaml
  - id: set-matrix
    run: echo "::set-output name=matrix::{\"include\":[{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL1 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME1 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL2 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME2 }}\"},{\"ARTIFACT_URL\":\"${{ env.ARTIFACT_URL3 }}\",\"PRODUCT_NAME\":\"${{ env.PRODUCT_NAME3 }}\"}]}"

```
## 3. sbom-upload
Sbom generation is done after build steps are done as a post build step only for the default branch.
To enable sbom generation the inputs like product-name , product-version and dist-list are taken from https://github.com/glcp/managed-ci-workflow/tree/sbom_upload/utils/vtn-config.yaml.
```yaml
Generic:
  - name: 'properties'
    org-name: 'GreenLake'
    api-url: 'https://vtn.hpecorp.net/api'
 
Projects:
  - name: 'platform-analytics-ingest-etl'
    product-name: 'platform-analytics-ingest-etl'
    product-version: '1.0.0'
    dist-list: 'giotto-devops'
``` 
Sbom generation and upload to VTN is done from the runner label ```managed-ci-vtn```. The action it uses is ```glcp/managed-ci-workflow/actions/upload-sbom@2.0.0``` which internally uses ```hpe-actions/cosign@v3``` action for signing and few vtn api calls to upload the sbom to VTN.
The job performs the cosign, verify and uploding sbom to VTN. The job is executed only on default_branch

**The following steps are executed when conditions are satisfied**.
|   | _Description_                                                   | _Actions_                                                     | _Execution_                                 |
|:-:|:----------------------------------------------------------------|:--------------------------------------------------------------|:--------------------------------------------|
| 1 | Download and unzip workspace artifacts uploaded in previous job | ```actions/download-artifact@v3```                            | The step is executed on only default branch |
| 2 | set-environment variables for the job.                          | ```actions-tools/yaml-outputs@v2```                           | The step is executed on only default branch |
| 3 | Docker Login to jfrog artifactory                               | ```docker/login-action@v2```                                  | The step is executed on only default branch |
| 4 | Docker Login to quay                                            | ```docker/login-action@v2```                                  | The step is executed on only default branch |
| 5 | Cosign verify and upload sbom                                   | ```glcp/managed-ci-workflow/actions/upload-sbom@sbom_upload```| The step is executed on only default branch |


# 5. For python based libraries in GLCP
# Workflows based on Triggers:
There are three workflows based on the Triggers for **Managed CI**.
> * managed-ci-pr.yaml
> * managed-ci-merge.yaml
> * managed-ci-manual-build.yaml

The **Managed CI** is currently configured for 4 different triggers which will execute one of the three workflows above.

| _Trigger_             | _Workflow_ _Triggered_     |  _Description_                                                                                          |
|:---------------------:|:--------------------------:|:--------------------------------------------------------------------------------------------------------|
| **workflow_dispatch** |managed-ci-manual-build.yaml| To enable the teams make use of the Managed CI workflow in feature/non-default branches for manual CI   |
| **pull_request**      |managed-ci-pr.yaml.         | To trigger the Managed CI workflow when a PR is opened, updated.                                        |
| **push/merge**.       |managed-ci-merge.yaml.      | [branch: main, master, mainline]: To Trigger the Managed CI workfow when PR is merged to default branch.|
| **release**.          |managed-ci-merge.yaml.      | release:[released]: To Trigger the Managed CI workfow when a code is released.                          |


# The following jobs are executed as a part of the workflows
# pre-check:
The pre-check job is executed in all three **'managed-ci-*'** workflows. The pre-check job is used for validation of the CI. The workflow used for the execution of pre-check is [mci-pre-check.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-pre-check.yaml).

The jobs that are executed for python based application on pre-check
| _Jobs_             | _Description_                                                                  |
|--------------------|--------------------------------------------------------------------------------|
| **secret-scanner** | Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the latest commit code-owner. |
| **malware-scanner**| Malware scanner is executed without any conditions on all repositories. As the name suggests the jobs scans the malware in the repo on a Pull Request and reports it in the comments of the PR |
| **mci-python-lib** | python job is intended for libraries based on **python**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python-lib'**].|

## 1. secret-scanner:
  Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner.
  The workflow used for the execution of secret-scanner is [scanning-workflow.yml](https://github.com/glcp/Secret-Scan-Tool/blob/main/.github/workflows/scanning-workflow.yml)

### Deafult Inputs for secret-scan
| _Input_             | _Default_                               | _Description_                                                       | _Required_  |
|:-------------------:|:----------------------------------------|:--------------------------------------------------------------------|:------------|
| repo                | ```${{github.event.repository.name}}``` | Name of the repository where secret scan need to be executed        | true        |
| branch              | ```${{github.ref_name}}```              | Branch in which secret-scan need to be executed on the given repo   | true        |

## 2. malware-scanner:
  Malware Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the malware in the repo on a Pull Request and reports it in the comments of the PR. if any malware is found the workflow will fail. The scan summary is reported to the comments of the PR irrespective of the result of the scan.

 The workflow used for the execution of malware-scanner is [malware scan workflow](.github/workflows/mci-clamav.yaml). There is no varaiable or parameter needed for this worklow.

## 3. mci-python-lib:
The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python-lib'**]. 

  **when the conditions are satisfied the job does the following actions in order.**

  |   | _description_                          | _actions_                                     | _execution_                          |
  |:-:|:---------------------------------------|:----------------------------------------------|:-------------------------------------|
  | 1 | Clone the Repository                   |```actions/checkout@v3.3.0```                  | The step is executed on all triggers |
  | 2 | Variables restore                      |```glcp/mci-actions-variables-restore@v2```    | The step is executed on all triggers |
  | 3 | Variables backup                       |```glcp/mci-actions-variables-backup@v2```     | The step is executed on all triggers |
  | 4 | PR title validation                    |```glcp/mci-actions-pr-title-validation@v1.0```| The step is executed only on PR      |
  | 5 | workspace backup                       |```actions/upload-artifact@v3```               | The step is executed on all triggers |

## Inputs/Secrets for mci-python-lib
| _Input_            | _Default_                                  | _Description_                                              | _Required_ |
|:-------------------|:-------------------------------------------|:-----------------------------------------------------------|:---------- |
| pull_request_title | ```${{ github.event.pull_request.title }```| The title of PR                                            | true       |
| jira_user          | ```${{ secrets.CCS_JIRA_USER }}```         | User to connect HPE JIRA                                   | true       |
| jira_apikey        | ```${{ secrets.CCS_JIRA_APIKEY }}```       | API Key to connect HPE JIRA                                | true       |
| gh_token           | ```${{ env.GITHUB_APP_TOKEN }}```         | Github Token                                               | true       |

# pre-stage:
The pre-stage job depends on the pre-check job. The pre-stage workflow need/will be in the application repository **.github/workflows** folder. This is just a boilerplate workflow, which the application team can use to execute project specific jobs before Lint that cann't be incorporated in MANAGED CI. The reference workflow for pre-stage is [mci-pre-stage.yaml](templates/mci-pre-stage.yaml)

# lint:
Lint job depends on pre-stage job and is executed only on PR. The workflow that is used for the execution of lint [mci-lint.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-lint.yaml). For python based libraries the **mci-python-lib** job is triggered.

## 1. mci-python-lib:
The lint job is configured to be executed only on PR. The job is executed based on the conditions provided in **Repository Variables**, **if: vars.GLCP_BUILD_SYSTEM == 'python-lib' && github.event_name == 'pull_request'**.

**when the conditions are satisfied the job does the following actions.**

|   | _Description_                | _Actions_                                                    | _Execution_                          |
|:-:|:-----------------------------|:-------------------------------------------------------------|:-------------------------------------|
| 1 | Workspace restore            | ```glcp/mci-actions-workspace-restore@v1```                  | The step is executed only on PR      |
| 2 | Variables restore            |```glcp/mci-actions-variables-restore@v2```.                  | The step is executed only on PR      |
| 3 | BootStrap Dev Environment    | ```glcp/mci-actions-bootstrap-dev-env@v1.0``` | The step is executed only on PR      |
| 4 | Linting for Python Libraries | Executed using bash commands as  in ```4*```                 | The step is executed only on PR      |
| 5 | Variables Backup             | ```actions/upload-artifact@v3```                             | The step is executed only on PR      |
| 6 | workspace backup             |```actions/upload-artifact@v3```                              | The step is executed only on PR      |

  4*. Linting using
  ```yaml
    - name: Lint
      id: lint
      shell: bash
      run: |
          cd $GITHUB_WORKSPACE/${{ env.DEV_ENV_DIR }}
          #!/bin/bash -x
          ws/${{ env.APP_NAME }}/automation/ci/run-in-ccs-dev.sh \
            ${{ env.DC_PROJECT_NAME }} \
            poetry run scripts/lint.sh
  ```
All Libraries based on python on-boarded to Managed CI need to have lint.sh script available in scripts folder of their repositories.

### Inputs/Secrets for mci-python-lib
| _Input_                | _Default_                                                | _Description_                             | _Required_ |
|:-----------------------|:---------------------------------------------------------|:------------------------------------------|:---------- |
| username/quay_username | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```.         | Quay Username                             | true       |
| password/quay_password | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                             | true       |
| DEV_ENV_DIR            | ```${{ env.DEV_ENV_DIR }}```                             | glcp/dev-env repository clone path.       | true       |
| DC_PROJECT_NAME        | ```${{ env.DC_PROJECT_NAME }}```                         | Name of the project                       | true       |
| jfrog_user             | ```${{ secrets.CCS_JFROG_USERNAME }}```                  | JFROG Username                            | true       |
| jfrog_passwd           | ```${{ secrets.CCS_JFROG_PASSWORD }}```                  | JFROG password                            | true       |
| devenv_tag             |  ```${{ env.DEV_ENV_TAG }}```                            | glcp/dev-env version                      | true       |
| APP_NAME               | ```${{ env.APP_NAME }}```                                | Name of the Library(usually repo name)    | true       |
| gh_token               | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                              | true       |


# pre-test:
The pre-test job depends on the lint job. The pre-test workflow need/will be in the repository **.github/workflows** folder. This is just a boilerplate workflow, which is the application team can use to execute project specific jobs before unit-test that cann't be incorporated in MANAGED CI. The reference workflow for pre-test is [mci-pre-test.yaml](templates/mci-pre-test.yaml)


# unit-test:
The unit-test depends on pre-test job. The workflow that is used for the execution of Unit Test [mci-unit-test.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-unit-test.yaml) and Code Quality check using sonarqube. For python based Libraries the **mci-python-lib** job is triggered.

## 1. mci-python-lib:
  mci-python-lib job is intended for Libraries based on **python**. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python-lib'**]. 

  **when the conditions are satisfied the job does the following actions.**

|   | _Description_                  | _Actions_                                                    | _Executions_                         |
|:-:|:-------------------------------|:-------------------------------------------------------------|:-------------------------------------|
| 1 | Workspace restore              | ```glcp/mci-actions-workspace-restore@v1```                  | The step is executed on all triggers |
| 2 | Variables restore              | ```glcp/mci-actions-variables-restore@v2```                  | The step is executed on all triggers |
| 3 | BootStrap Dev Environment      | ```glcp/mci-actions-bootstrap-dev-env@v1.0```                | The step is executed on all triggers |
| 4 | Unit Test for Python Libraries | Executed using bash commands as  in ```4*```                 | The step is executed on all triggers |
| 5 | Override Python Coverage Source Path | Executed using bash commands as  in ```5*```           | The step is executed on all triggers |
| 6 | SonarQube Scan                 | ```hpe-actions/sonarqube-scan@main```                        | The step is executed on all triggers |
| 8 | workspace backup               | ```actions/upload-artifact@v3```                             | The step is executed on all triggers |

  4*. Executing unit-test using poetry. All Libraries based on python should have their test script named test.sh in the scripts folder of their repository
  ```yaml
    - name: Unit Tests
      id: unit_tests
      shell: bash
      run: |
        cd $GITHUB_WORKSPACE/${{ env.DEV_ENV_DIR }}
        ws/${{ env.APP_NAME }}/automation/ci/run-in-ccs-dev.sh \
            ${{ env.DC_PROJECT_NAME }} \
          poetry run scripts/test.sh
  ```
 5*. Overiding spurce path in coverage.xml for SonarQube code coverage analysis.
```
      - name: Override Python Coverage Source Path for Sonar
        shell: bash
        run: |
          file=$(find . -name coverage.xml -print)
          if [[ -z "${{ env.APP_DIR }}" ]]; then export APP_DIR=app ; fi
          sed -i -e "s,<source>.*</source>,<source>/github/workspace/${{env.DEV_ENV_DIR}}/ws/${{env.APP_NAME}}/${{ env.APP_DIR }}/</source>,g" $file
```
### Inputs/Secrets for mci-python-lib
| _Input_                | _Default_                                              | _Description_                           | _Required_ |
|:-----------------------|:-------------------------------------------------------|:----------------------------------------|:---------- |
| username/quay_username |```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```         | Quay Username                           | true       |
| password/quay_password |```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}```| Quay Password                           | true       |
| DEV_ENV_DIR            |```${{ env.DEV_ENV_DIR }}```                            | glcp/dev-env repository clone path      | true       |
| DC_PROJECT_NAME        |```${{ env.DC_PROJECT_NAME }}```                        | Name of the project                     | true       |
| jfrog_user             |```${{ secrets.CCS_JFROG_USERNAME }}```                 | JFROG Username                          | true       |
| jfrog_passwd           |```${{ secrets.CCS_JFROG_PASSWORD }}```                 | JFROG password                          | true       |
| devenv_tag             |```${{ env.DEV_ENV_TAG }}```                            | glcp/dev-env version                    | true       |
| APP_NAME               | ```${{ env.APP_NAME }}```                              | Name of the Library(usually repo name)  | true       |
| gh_token               | ```${{ env.GITHUB_APP_TOKEN }}```                     | Github Token                            | true       |


# build:
build depends on unit-test job. The workflow that is used for the execution of build [mci-build.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-build.yaml). For python based Libraries the **mci-python-lib** job is triggered. The build job is triggered only on merge/push or when a release is created.

## 1. mci-python-lib
  Building or packaging of the artifacts for python based Libraries in GLCP are done using the workflow [mci-build-python-lib.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-build-python-lib.yaml). The workflow is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'python'**]. The Jobs executed by mci-build-python-lib.yaml are **create-tag, build-publish**.

### a. create-tag 
The tag for the build is determinied and set as output using the create-tag job. the create-tag is executed only on main.

**The following steps are executed in order in create-tag job**.
|   | _description_                          | _actions_                                              | 
|:-:|:---------------------------------------|:-------------------------------------------------------|
| 1 | Cloning the application repository     | ```actions/checkout@v3.3.0```                          |
| 2 | Variables restore                      | ```glcp/mci-actions-variables-restore@v2```            | 
| 3 | Create Tag for the build               | ```glcp/mci-actions-tag-git@v1.0```     |

### b. build-publish
  The build-publish job is used build and publish the library to artifactory.

The following stpes are executed in order.
|   | _description_                           | _actions_                                   |
|:-:|:----------------------------------------|:--------------------------------------------| 
| 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```               | 
| 2 | Variables restore                       | ```glcp/mci-actions-variables-restore@v2``` | 
| 3 | Build and Publish                       | ```glcp/mci-actions-build/lib-build@main``` | 

#### Inputs/Secrets for build-publish 

| _Input_        | _Default_                                 | _Description_                           | _Required_ |
|:---------------|:------------------------------------------|:----------------------------------------|:---------- |
| TAG            | ```${{ needs.create-tag.outputs.tag }}``` | TAG for the build and publish           | true       |
| SECRETS        | ```${{ toJSON(secrets) }}```              | Importing all secrets to the action     | true       |
=======

# 6. For Shell script repos in GLCP
# Workflows based on Triggers:
There are three workflows based on the Triggers for **Managed CI**.
> * managed-ci-pr.yaml
> * managed-ci-merge.yaml
> * managed-ci-manual-build.yaml

The **Managed CI** is currently configured for 4 different triggers which will execute one of the three workflows above.

| _Trigger_             | _Workflow_ _Triggered_     |  _Description_  |                                                   
|:---------------------:|:--------------------------:|:----------------------------------------------------------------------------------|
| **workflow_dispatch** |managed-ci-manual-build.yaml| To enable the teams make use of the Managed CI workflow in feature/non-default branches for manual CI|
| **pull_request**      |managed-ci-pr.yaml.         | To trigger the Managed CI workflow when a PR is opened, updated.|                          
| **push/merge**.       |managed-ci-merge.yaml.      | [branch: main, master, mainline]: To Trigger the Managed CI workfow when PR is merged to default branch.|
| **release**.          |managed-ci-merge.yaml.      | release:[released]: To Trigger the Managed CI workfow when a code is released.|


# The following jobs are executed as a part of the workflows
# pre-check:
The pre-check job is executed in all three **'managed-ci-*'** workflows. The pre-check job is used for validation of the CI. The workflow used for the execution of pre-check is [mci-pre-check.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-pre-check.yaml).

The jobs that are executed for script based application on pre-check
| _Jobs_             | _Description_                                                                  |
|--------------------|--------------------------------------------------------------------------------|
| **secret-scanner** | Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the latest commit code-owner. |
| **malware-scanner**| Malware scanner is executed without any conditions on all repositories. As the name suggests the jobs scans the malware in the repo on a Pull Request and reports it in the comments of the PR |
| **mci-shell** |  job is intended for shell script based repos. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'shell'**].|

## 1. secret-scanner:
  Secret Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the unencrypted/plain-text secrets/passwords in the latest commit and reports it to the code-owner.
  The workflow used for the execution of secret-scanner is [scanning-workflow.yml](https://github.com/glcp/Secret-Scan-Tool/blob/main/.github/workflows/scanning-workflow.yml)

### Deafult Inputs for secret-scan
| _Input_             | _Default_                               | _Description_                                                       | _Required_  |
|:-------------------:|:----------------------------------------|:--------------------------------------------------------------------|:------------|
| repo                | ```${{github.event.repository.name}}``` | Name of the repository where secret scan need to be executed        | true        |
| branch              | ```${{github.ref_name}}```              | Branch in which secret-scan need to be executed on the given repo   | true        |

## 2. malware-scanner:
  Malware Scanner is executed without any conditions on all repositories. As the name suggests the jobs scans for the malware in the repo on a Pull Request and reports it in the comments of the PR. if any malware is found the workflow will fail. The scan summary is reported to the comments of the PR irrespective of the result of the scan.

 The workflow used for the execution of malware-scanner is [malware scan workflow](.github/workflows/mci-clamav.yaml). There is no varaiable or parameter needed for this worklow.

## 3. mci-shell:
The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'shell'**]. 

  **when the conditions are satisfied the job does the following actions in order.**

  |   | _description_                          | _actions_                                 | _execution_                          |
  |:-:|:---------------------------------------|:------------------------------------------|:-------------------------------------|
  | 1 | Clone the Repository                   |```actions/checkout@v3.3.0```              | The step is executed on all triggers |
  | 2 | Variables restore                      |```glcp/mci-actions-variables-restore@v2```| The step is executed on all triggers |
  | 3 | Variables backup                       |```glcp/mci-actions-variables-backup@v2``` | The step is executed on all triggers |
  | 4 | workspace backup                       |```actions/upload-artifact@v3```           | The step is executed on all triggers |

## Inputs/Secrets for mci-shell
| _Input_            | _Default_                                  | _Description_                                              | _Required_ |
|:-------------------|:-------------------------------------------|:-----------------------------------------------------------|:---------- |
| gh_token           | ```${{ env.GITHUB_APP_TOKEN }}```         | Github Token                                               | true       |

# pre-stage:
The pre-stage job depends on the pre-check job. The pre-stage workflow need/will be in the application repository **.github/workflows** folder. This is just a boilerplate workflow, which the application team can use to execute project specific jobs before Lint that cann't be incorporated in MANAGED CI. The reference workflow for pre-stage is [mci-pre-stage.yaml](templates/mci-pre-stage.yaml)

# lint:
Lint job depends on pre-stage job and is executed only on PR. The workflow that is used for the execution of lint [mci-lint.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-lint.yaml). For script based repos the **mci-shell** job is triggered.

## 1. mci-shell:
The lint job is configured to be executed only on PR. The job is executed based on the conditions provided in **Repository Variables**, **if: vars.GLCP_BUILD_SYSTEM == 'shell' && github.event_name == 'pull_request'**.

**when the conditions are satisfied the job does the following actions.**

|   | _Description_                | _Actions_                                                    | _Execution_                          |
|:-:|:-----------------------------|:-------------------------------------------------------------|:-------------------------------------|
| 1 | Workspace restore            | ```glcp/mci-actions-workspace-restore@v1```                  | The step is executed only on PR      |
| 2 | Variables restore            |```glcp/mci-actions-variables-restore@v2```.                  | The step is executed only on PR      |
| 3 | Lint for shell script based repos| Executed using super lint action as  in ```4*```         | The step is executed only on PR      |
| 4 | Variables Backup             | ```actions/upload-artifact@v3```                             | The step is executed only on PR      |
| 5 | workspace backup             |```actions/upload-artifact@v3```                              | The step is executed only on PR      |

  4*. Linting using
  ```yaml
      - name: Super lint
        uses: glcp/mci-actions-lint/super-linter@v1
  ```

### Inputs/Secrets for mci-shell
| _Input_                | _Default_                                                | _Description_                             | _Required_ |
|:-----------------------|:---------------------------------------------------------|:------------------------------------------|:---------- |
| username/quay_username | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```.         | Quay Username                             | true       |
| password/quay_password | ```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}``` | Quay Password                             | true       |
| APP_NAME               | ```${{ env.APP_NAME }}```                                | Name of the Library(usually repo name)    | true       |
| gh_token               | ```${{ env.GITHUB_APP_TOKEN }}```                       | Github Token                              | true       |


# pre-test:
The pre-test job depends on the lint job. The pre-test workflow need/will be in the repository **.github/workflows** folder. This is just a boilerplate workflow, which is the application team can use to execute project specific jobs before unit-test that cann't be incorporated in MANAGED CI. The reference workflow for pre-test is [mci-pre-test.yaml](templates/mci-pre-test.yaml)


# unit-test:
The unit-test depends on pre-test job. The workflow that is used for the execution of Unit Test [mci-unit-test.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-unit-test.yaml) and Code Quality check using sonarqube. For shell script based repos the **mci-shell** job is triggered.

## 1. mci-shell:
  mci-shell job is intended for shell script based repos. The job is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'shell'**]. 

  **when the conditions are satisfied the job does the following actions.**

|   | _Description_                  | _Actions_                                                    | _Executions_                         |
|:-:|:-------------------------------|:-------------------------------------------------------------|:-------------------------------------|
| 1 | Workspace restore              | ```glcp/mci-actions-workspace-restore@v1```                  | The step is executed on all triggers |
| 2 | Variables restore              | ```glcp/mci-actions-variables-restore@v2```                  | The step is executed on all triggers |
| 3 | Run make test to run unit test | make test                                                    | The step is executed on all triggers |
| 4 | workspace backup               | ```actions/upload-artifact@v3```                             | The step is executed on all triggers |

  4*. Executing unit-test using Makefile.
  ```yaml
      - name: Run unit tests
        run: make test
  ```
### Inputs/Secrets for mci-shell
| _Input_                | _Default_                                              | _Description_                           | _Required_ |
|:-----------------------|:-------------------------------------------------------|:----------------------------------------|:---------- |
| username/quay_username |```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER }}```         | Quay Username                           | true       |
| password/quay_password |```${{ secrets.CCS_QUAY_CCSPORTAL_BUILDER_PASSWORD }}```| Quay Password                           | true       |
| APP_NAME               | ```${{ env.APP_NAME }}```                              | Name of the Library(usually repo name)  | true       |
| gh_token               | ```${{ env.GITHUB_APP_TOKEN }}```                     | Github Token                            | true       |


# build:
build depends on unit-test job. The workflow that is used for the execution of build [mci-build.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-build.yaml). The build job is triggered only on merge/push or when a release is created.

## 1. mci-shell
  Building or packaging of the artifacts for shell script based repos in GLCP are done using the workflow [mci-build-script.yaml](https://github.com/glcp/managed-ci-workflow/blob/v1.2.0/.github/workflows/mci-build-script.yaml). The workflow is executed based on the conditions provided in **Repository Variables** [**if: vars.GLCP_BUILD_SYSTEM == 'shell'**]. The Jobs executed by mci-build-script.yaml are **create-tag, build**.

### a. create-tag 
The tag for the build is determinied and set as output using the create-tag job. the create-tag is executed only on main.

**The following steps are executed in order in create-tag job**.
|   | _description_                          | _actions_                                              | 
|:-:|:---------------------------------------|:-------------------------------------------------------|
| 1 | Cloning the application repository     | ```actions/checkout@v3.3.0```                          |
| 2 | Variables restore                      | ```glcp/mci-actions-variables-restore@v2```            | 
| 3 | Create Tag for the build               |     |

### b. build
  The build job is used to run the given scripts with the given arguments from mci-variables.yaml.

The following stpes are executed in order.
|   | _description_                           | _actions_                                   |
|:-:|:----------------------------------------|:--------------------------------------------| 
| 1 | Cloning the application repository      | ```actions/checkout@v3.3.0```               | 
| 2 | Variables restore                       | ```glcp/mci-actions-variables-restore@v2``` |
  3*. Docker registry login
  ```yaml
    - uses: glcp/mci-actions-registry-login@v1
      with:
        secrets: ${{ toJson(secrets) }}
  ```     
  4*. Executing Build.
  ```yaml
      shell: bash
      run: |
        env
        if [[ "${{ env.DOCKER_PUSH }}" == "" ]]; then DOCKER_PUSH_VAR=1;else DOCKER_PUSH_VAR=${{ env.DOCKER_PUSH }}; fi
        if [[ "${{ env.SCRIPT_ARGS }}" == "" ]]; then SCRIPT_ARGS_VAR="$(echo ${{ needs.create-tag.outputs.tag }})";else SCRIPT_ARGS_VAR=${{ env.SCRIPT_ARGS }}; fi
        echo "DOCKER_PUSH=${DOCKER_PUSH_VAR} ${{ env.SCRIPT_TO_RUN }} ${SCRIPT_ARGS_VAR}"
  ```


# Hotfix-branch:
 Hotfix workflow is used to create a hot fix branch from the Tag which is passed as in input parameter. this workflow does the following steps
 
    ```
     1. create branch  out of Tag with name hotfix-<Tag> 
     2. add manage-ci-hotfix-<Tag>.yaml workflow to the branch 
     3. update the version in mci-variables
    ```
    
 Functions managed by manage-ci-hotfix:
  *  pre-check
     * secret scan
     * malware scanning
     * PR title check
     * copyright check
 *  lint
     * also includes code reformatting for languages that support it (ie: SBT/scala)
 *  unit tests
 *  build
 *  post-build
    * ![SonarQube](https://github.com/glcp/devx-sonarqube/tree/main) 
    * SigStore cosign container signing
    * SBOM upload to HPE VTN
 
 Functions left to the discretion of project owners:
 * pre-stage
 * pre-test

 manage-ci-hotfix.yaml workflow will run on push to hotfix-<Tag> branch and default core update channel for the build on this branch is "GLCP-HF". 
 To add hotfix workflow copy the below workflow 
 
 ```yaml
 


name: HOTFIX

on:
  workflow_dispatch:
    inputs:
      tag:
        description: 'Enter valid tag name'
        type: string
        required: true

jobs:
  hot-fix:
    permissions: write-all
    runs-on: ubuntu-latest
    steps:
      - name: Generate github app token
        id: generate_token
        uses: tibdex/github-app-token@v1.7.0
        with:
          app_id: ${{ secrets.ORG_POLICY_GITHUB_APP_ID }}
          private_key: ${{ secrets.ORG_POLICY_GITHUB_APP_PRIVATE_KEY }}

      - name: Use temporary github token as Env variable
        env:
          GITHUB_APP_TOKEN: ${{ steps.generate_token.outputs.token }}
        run: |
          echo "The generated token is masked: ${GITHUB_APP_TOKEN}"
          echo "GITHUB_APP_TOKEN=$GITHUB_APP_TOKEN" >> $GITHUB_ENV
          echo "GITHUB_PR_TOKEN=${{ secrets.PULL_REQUEST_SECRET }}" >> $GITHUB_ENV
        shell: bash

      - name: Clone App repo
        uses: actions/checkout@v3.3.0
        with:
          token: ${{ env.GITHUB_APP_TOKEN }}
          ref: ${{ inputs.tag }}
          


      - name: Clone Managed CI
        uses: actions/checkout@v3.3.0
        with:
          repository: glcp/managed-ci-workflow
          token: ${{ env.GITHUB_APP_TOKEN }}
          path: managed-ci
          ref: main

      - name: Create hotfix branch
        env:
          GITHUB_TOKEN: ${{ steps.generate_token.outputs.token }}
          GIT_AUTHOR_NAME: GLCP HOTFIX
          GIT_AUTHOR_EMAIL: glcp-gh-bot@github.com
          GIT_COMMITTER_NAME: GLCP HOTFIX
          GIT_COMMITTER_EMAIL: glcp-gh-bot@github.com
          Tag: ${{inputs.tag}}
        run: |
          chmod +x managed-ci/hotfix/scripts/hotfix.sh
          bash managed-ci/hotfix/scripts/hotfix.sh

```
# Sonar configuration:

When a repo is onboarded to Managed CI, that repo will automatically be onboarded to SonarQube. The Project name (repo name), Quality gate to be used, and the repo's default branch will be automatically added to the Projects section of `sonar.yaml`. The default Quality gate is `glcp-sonarqube`, which is maintained by the Giotto team.

Once your repo is onboarded with Managed CI, create a configuration file (`sonar-project.properties`) with project specific settings in the root directory of your project/repo.

 
## sonar-project.properties:

  ```  
#Must be unique in a given SonarQube instance
sonar.projectKey=my-project

#This is the name and version displayed in the SonarQube UI. Default to Projectkey if not provided.
sonar.projectName=My project
sonar.projectVersion=1.0

#Path is relative to the sonar-project.properties file.
#By default, sonar.sources is set to the current working directory and sonar.tests is not set.       
#Test code analysis rules are different and Test code does not count toward lines-of-code limits defined by our license
sonar.sources = src/
sonar.tests = tests/

#Exclude subdirectories from analysis which are not needed 
sonar.exclusions = src/**/test/**/*

#For python :This parameter must be set to the path of the report file produced by your coverage tool 
sonar.python.coverage.reportPaths=coverage.xml

#For golang:This parameter must be set to the path of the report file produced by your coverage tool
sonar.go.coverage.reportPaths=cover.out
  ```  
## Narrowing focus
To help narrow the focus, SonarQube gives you several options to precisely configure what will be analyzed and how.                                          
Documentation is available [here](https://docs.sonarsource.com/sonarqube/9.9/project-administration/narrowing-the-focus/)
 
## Additional properties documentation
* Generic properties are documented [here](https://docs.sonarqube.org/latest/analyzing-source-code/analysis-parameters/)
* [GoLang specific properties](https://docs.sonarqube.org/latest/analyzing-source-code/languages/go/)
* [Java specific properties](https://docs.sonarqube.org/latest/analyzing-source-code/languages/java/)
* [Python specific properties](https://docs.sonarqube.org/latest/analyzing-source-code/languages/python/)
* [Javascript/npm specific properties](https://docs.sonarqube.org/latest/analyzing-source-code/languages/javascript-typescript-css/)

Repository for SonarQube Management [here](https://github.com/glcp/devx-sonarqube/blob/main/README.md)
